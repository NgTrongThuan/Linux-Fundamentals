/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5kiemTraSoNTJUnitTest {

    public Bai5kiemTraSoNTJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testSoNT_1() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(0);
        assertFalse(ac);
    }
    @Test
    public void testSoNT_2() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(1);
        assertFalse(ac);
    }
    @Test
    public void testSoNT_3() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(4);
        assertFalse(ac);
    }
    @Test
    public void testSoNT_4() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(6);
        assertFalse(ac);
    }
    @Test
    public void testSoNT_5() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(8);
        assertFalse(ac);
    }
    @Test
    public void testSoNT_6() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(0);
        assertTrue(ac);
    }
    @Test
    public void testSoNT_7() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(1);
        assertTrue(ac);
    }
    @Test
    public void testSoNT_8() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(4);
        assertTrue(ac);
    }
    @Test
    public void testSoNT_9() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(6);
        assertTrue(ac);
    }
    @Test
    public void testSoNT_10() {
        boolean ac = bai5nguyentrongthuan.ktSoNT.kiemTraSoNTFor(8);
        assertTrue(ac);
    }
}
