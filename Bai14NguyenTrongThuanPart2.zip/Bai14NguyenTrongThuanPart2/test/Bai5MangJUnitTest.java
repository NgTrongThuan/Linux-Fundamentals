/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5MangJUnitTest {

    public Bai5MangJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testTimX_1() {
        int ex = 0;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(1, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_2() {
        int ex = 2;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(3, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_3() {
        int ex = 1;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(2, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_4() {
        int ex = 2;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(0, new int[]{1, 2, 0, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_5() {
        int ex = 4;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(7, new int[]{1, 4, 5, 6, 7});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_6() {
        int ex = -1;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(1, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_7() {
        int ex = -1;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(3, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_8() {
        int ex = 0;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(2, new int[]{1, 2, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_9() {
        int ex = 1;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(0, new int[]{1, 2, 0, 3});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimX_10() {
        int ex = -1;
        int ac = bai5nguyentrongthuan.timKiemTrongMang.timX(7, new int[]{1, 4, 5, 6, 7});
        assertEquals(ex, ac);
    }

}
