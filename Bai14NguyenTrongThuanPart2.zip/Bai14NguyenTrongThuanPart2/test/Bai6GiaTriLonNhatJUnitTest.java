/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai6GiaTriLonNhatJUnitTest {
    
    public Bai6GiaTriLonNhatJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTimGiaTriLonNhat_1() {
        int ex = 2;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{0, 1, 2}, {1, 2, 0}, {1, 0, 2}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_2() {
        int ex = 2;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{2, 1, 0}, {0, 1, 2}, {2, 1, 0}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_3() {
        int ex = 2;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{1, 0, 2}, {1, 2, 0}, {2, 1, 0}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_4() {
        int ex = 2;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{2, 0, 1}, {2, 1, 0}, {1, 0, 2}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_5() {
        int ex = 3;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{1, 2}, {1, 3}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_6() {
        int ex = 0;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{0, 1, 2}, {1, 2, 0}, {1, 0, 2}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_7() {
        int ex = 1;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{2, 1, 0}, {0, 1, 2}, {2, 1, 0}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_8() {
        int ex = 1;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{1, 0, 2}, {1, 2, 0}, {2, 1, 0}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_9() {
        int ex = 1;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{2, 0, 1}, {2, 1, 0}, {1, 0, 2}});
        assertEquals(ex, ac);
    }

    @Test
    public void testTimGiaTriLonNhat_10() {
        int ex = 1;
        int ac = bai6nguyentrongthuan.xulyMaTranVuong.
                timGiaTriLonNhat(new int[][]{{1, 2}, {1, 3}});
        assertEquals(ex, ac);
    }
}
