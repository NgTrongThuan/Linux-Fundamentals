/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TinhTongSoChanJUnitTest {
    
    public Bai5TinhTongSoChanJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTinhTongSoChan_1(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_2(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_3(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_4(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_5(){
        double ex = 6;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(4);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_6(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_7(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_8(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_9(){
        double ex = 3;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoChan_10(){
        double ex = 3;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoChanFor(4);
        assertEquals(ex, ac, 0);
    }
}
