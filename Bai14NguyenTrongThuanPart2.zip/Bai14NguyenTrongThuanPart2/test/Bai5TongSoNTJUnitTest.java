/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TongSoNTJUnitTest {
    
    public Bai5TongSoNTJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTongSoNT_1(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_2(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_3(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_4(){
        double ex = 5;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_5(){
        double ex = 5;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(4);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_6(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_7(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_8(){
        double ex = 3;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_9(){
        double ex = 6;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongSoNT_10(){
        double ex = 10;
        double ac = bai5nguyentrongthuan.tinhGTBT.tongSoNTFor(4);
        assertEquals(ex, ac, 0);
    }
}
