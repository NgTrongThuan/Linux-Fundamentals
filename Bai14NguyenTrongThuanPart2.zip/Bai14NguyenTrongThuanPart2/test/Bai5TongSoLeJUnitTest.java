/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TongSoLeJUnitTest {
    
    public Bai5TongSoLeJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTinhTongSoLe_1(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_2(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_3(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_4(){
        double ex = 4;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_5(){
        double ex = 4;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(4);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_6(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_7(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_8(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_9(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTongSoLe_10(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTongSoLeFor(4);
        assertEquals(ex, ac, 0);
    }
}
