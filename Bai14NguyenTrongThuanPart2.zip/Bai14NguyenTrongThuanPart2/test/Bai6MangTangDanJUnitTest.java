/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai6MangTangDanJUnitTest {

    public Bai6MangTangDanJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testKiemTraMangTangDan_1() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{4, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangTangDan_2() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 2, 4, 3}));
    }

    @Test
    public void testKiemTraMangTangDan_3() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 2, 9, 1}));
    }

    @Test
    public void testKiemTraMangTangDan_4() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{9, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangTangDan_5() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 9, 3, 3}));
    }
    @Test
    public void testKiemTraMangTangDan_6() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{4, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangTangDan_7() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 2, 4, 3}));
    }

    @Test
    public void testKiemTraMangTangDan_8() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 2, 9, 1}));
    }

    @Test
    public void testKiemTraMangTangDan_9() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{9, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangTangDan_10() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangTangDan(new int[]{1, 9, 3, 3}));
    }
    
}
