/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai6MangGiamDanJUnitTest {
    
    public Bai6MangGiamDanJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testKiemTraMangGiamDan_1() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{4, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangGiamDan_2() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 2, 4, 3}));
    }

    @Test
    public void testKiemTraMangGiamDan_3() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 2, 9, 1}));
    }

    @Test
    public void testKiemTraMangGiamDan_4() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{9, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangGiamDan_5() {
        assertFalse(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 9, 3, 3}));
    }
    @Test
    public void testKiemTraMangGiamDan_6() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{4, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangGiamDan_7() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 2, 4, 3}));
    }

    @Test
    public void testKiemTraMangGiamDan_8() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 2, 9, 1}));
    }

    @Test
    public void testKiemTraMangGiamDan_9() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{9, 2, 3, 4}));
    }

    @Test
    public void testKiemTraMangGiamDan_10() {
        assertTrue(bai6nguyentrongthuan.kiemTraMangMotChieu.kiemTraMangGiamDan(new int[]{1, 9, 3, 3}));
    }
}
