/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class Bai5VeBanCo {

    public static String[][] veBanCo() {
        String[][] banCo = new String[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (((i + j) % 2 == 0) || (i == j)) {
                    banCo[i][j] = "W";
                } else {
                    banCo[i][j] = "B";
                }
            }
        }
        return banCo;
    }

    public static void inBanCo(String[][] banCo) {
        for (int i = 0; i < 8; i++) {
            System.out.println("--------------------------------------------------------");
            for (int j = 0; j < 8; j++) {

                System.out.print(" | " + banCo[i][j] + " | ");
            }
            System.out.print("\n");
        }
        System.out.println("--------------------------------------------------------");
    }

    public static void main(String[] args) {
        String[][] banCo = new String[8][8];
        banCo = veBanCo();
        inBanCo(banCo);
    }
}
