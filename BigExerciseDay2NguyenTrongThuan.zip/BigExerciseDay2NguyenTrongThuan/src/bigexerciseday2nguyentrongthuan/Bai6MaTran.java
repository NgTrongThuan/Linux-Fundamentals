/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class Bai6MaTran {

    public static String[][] veCauA() {
        String[][] a = new String[11][11];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] = " ";
            }
        }
        for (int i = 0; i < a.length; i++) {
            for (int j = i; j < a[i].length; j++) {
                if (j < a[i].length - i) {
                    a[i][j] = "#";
                }
            }
        }

        return a;
    }

    public static String[][] veCauB() {
        String[][] a = new String[11][11];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] = " ";
            }
        }

        for (int i = 0; i < a.length / 2 + 1; i++) {
            for (int j = a.length / 2 - i; j < a.length / 2 + i + 1; j++) {
                a[i][j] = "#";
            }
        }
        return a;
    }

    public static String[][] veCauC() {
        int k = 1;

        String[][] B = veCauB();
        String[][] C = B.clone();
        String[][] A = veCauA();
        for (int i = B.length / 2 + 1; i < B.length; i++) {
            int l = 0;
            for (int j = 0; j < B[i].length; j++) {
                C[i][j] = A[k][l];
                l++;
            }
            k++;
        }
        return C;
    }

    public static void inMaTran(String[][] matran) {
        for (int i = 0; i < matran.length; i++) {
            for (int j = 0; j < matran[i].length; j++) {
                System.out.print(matran[i][j] + " ");
            }
            System.out.println("");
        }
    }

    public static void veHinhD() {
        int[][] a = new int[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i >= j) {
                    System.out.print(j + 1 + " ");
                }
            }
            System.out.println("");
        }
    }

    public static void veHinhE() {
        String[][] mang = new String[8][8];
        int k = 1;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (j >= i) {
                    System.out.print(k + " ");
                    k++;
                } else {
                    System.out.print("  ");
                }
            }
            k = 1;
            System.out.println("");
        }
    }

    public static void veHinhF() {
        int[][] a = new int[8][8];
        int tam = 8;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (j >= 8 - i) {
                    System.out.print(tam);
                } else {
                    System.out.print(" ");
                }
                tam--;
            }
            tam = 8;
            System.out.println("");
        }
    }

    public static void veHinhG() {
        int[][] a = new int[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 8; j > 0; j--) {
                if (i + j <= 8) {
                    System.out.print(j + " ");
                }
            }
            System.out.println("");
        }
    }

    public static void main(String[] args) {
        System.out.println("Ve hinh cau a:");
        inMaTran(veCauA());
        System.out.println("-----------------------------");

        System.out.println("Ve hinh cau b:");
        inMaTran(veCauB());
        System.out.println("-----------------------------");

        System.out.println("Ve hinh cau c:");
        inMaTran(veCauC());
        System.out.println("-----------------------------");

        System.out.println("Ve hinh cau d:");
        veHinhD();
        System.out.println("-----------------------------");
        System.out.println("Ve hinh cau e:");
        veHinhE();
        System.out.println("-----------------------------");
        System.out.println("Ve hinh cau f:");
        veHinhF();
        System.out.println("-----------------------------");
        System.out.println("Ve hinh cau g:");
        veHinhG();
    }

}
