/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2TienNuoc {

    enum KHONGSINHHOAT {
        DVSX(9600, 480, 960, 11040), CQ(10300, 515, 1030, 11845), DVKD(16900, 845, 1690, 19435);
        private double giaNuoc;
        private double thueGTGT;
        private double phiBVMT;
        private double cong;

        private KHONGSINHHOAT(double giaNuoc, double thueGTGT, double phiBVMT, double cong) {
            this.giaNuoc = giaNuoc;
            this.thueGTGT = thueGTGT;
            this.phiBVMT = phiBVMT;
            this.cong = cong;
        }

        public double getGiaNuoc() {
            return giaNuoc;
        }

        public double getThueGTGT() {
            return thueGTGT;
        }

        public double getPhiBVMT() {
            return phiBVMT;
        }

        public double getCong() {
            return cong;
        }

        public double[] tinhTien(double soNuoc) {
            double[] kq = new double[4];
            switch (this) {
                case DVSX: {
                    kq[0] = this.getGiaNuoc() * soNuoc;
                    kq[1] = this.getThueGTGT() * soNuoc;
                    kq[2] = this.getPhiBVMT() * soNuoc;
                    kq[3] = this.getCong() * soNuoc;
                }
                break;
                case CQ: {
                    kq[0] = this.getGiaNuoc() * soNuoc;
                    kq[1] = this.getThueGTGT() * soNuoc;
                    kq[2] = this.getPhiBVMT() * soNuoc;
                    kq[3] = this.getCong() * soNuoc;
                }
                break;
                case DVKD: {
                    kq[0] = this.getGiaNuoc() * soNuoc;
                    kq[1] = this.getThueGTGT() * soNuoc;
                    kq[2] = this.getPhiBVMT() * soNuoc;
                    kq[3] = this.getCong() * soNuoc;
                }
                break;
            }
            return kq;
        }
    }

    enum SINHHOAT {
        GIANUOC(5300, 10200, 11400),
        GTGT(265, 510, 570),
        BVMT(530, 1020, 1140),
        CONG(6095, 11730, 13110);
        private double bac1;
        private double bac2;
        private double bac3;

        private SINHHOAT(double bac1, double bac2, double bac3) {
            this.bac1 = bac1;
            this.bac2 = bac2;
            this.bac3 = bac3;
        }

        public double getBac1() {
            return bac1;
        }

        public double getBac2() {
            return bac2;
        }

        public double getBac3() {
            return bac3;
        }

    }

    public static double[] tinhTien(double soNuoc, int soNguoi) {
        double[] soTien = new double[4];
        double tieuThuTB = soNuoc / soNguoi;
        SINHHOAT sh = null;

        if (tieuThuTB <= 4) {
            soTien[0] = soNuoc * sh.GIANUOC.getBac1();
            soTien[1] = soNuoc * sh.GTGT.getBac1();
            soTien[2] = soNuoc * sh.BVMT.getBac1();
            soTien[3] = soNuoc * sh.CONG.getBac1();
        } else if (tieuThuTB <= 6) {
            soTien[0] = ((tieuThuTB - 4) * sh.GIANUOC.getBac2() + 4 * sh.GIANUOC.getBac1()) * soNguoi;
            soTien[1] = ((tieuThuTB - 4) * sh.GTGT.getBac2() + 4 * sh.GTGT.getBac1()) * soNguoi;
            soTien[2] = ((tieuThuTB - 4) * sh.BVMT.getBac2() + 4 * sh.BVMT.getBac1()) * soNguoi;
            soTien[3] = ((tieuThuTB - 4) * sh.CONG.getBac2() + 4 * sh.CONG.getBac1()) * soNguoi;
        } else {
            soTien[0] = ((tieuThuTB - 6) * sh.GIANUOC.getBac3() + 2 * sh.GIANUOC.getBac2() + 4 * sh.GIANUOC.getBac1()) * soNguoi;
            soTien[1] = ((tieuThuTB - 6) * sh.GTGT.getBac3() + 2 * sh.GTGT.getBac2() + 4 * sh.GTGT.getBac1()) * soNguoi;
            soTien[2] = ((tieuThuTB - 6) * sh.BVMT.getBac3() + 2 * sh.BVMT.getBac2() + 4 * sh.BVMT.getBac1()) * soNguoi;
            soTien[3] = ((tieuThuTB - 6) * sh.CONG.getBac3() + 2 * sh.CONG.getBac2() + 4 * sh.CONG.getBac1()) * soNguoi;
        }

        return soTien;
    }

    public static double[] tinhTienKhongSH(double soNuoc, int loai) {
        if (soNuoc <= 0) {
            throw new ArithmeticException("Nhap so nuoc khong hop le");
        }
        double kq[] = new double[4];
        KHONGSINHHOAT ksh = null;
        switch (loai) {
            case 1:
                kq = ksh.DVSX.tinhTien(soNuoc);
                break;
            case 2:
                kq = ksh.CQ.tinhTien(soNuoc);
                break;
            case 3:
                kq = ksh.DVKD.tinhTien(soNuoc);
                break;
        }
        return kq;
    }

    public static void xuatKetQua(double[] kq) {
        System.out.println("Tien nuoc khong thue va phi: " + kq[0]);
        System.out.println("Tien thue GTGT: " + kq[1]);
        System.out.println("Tien phi bao ve moi truong: " + kq[2]);
        System.out.println("Tien phai tra: " + kq[3]);
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so nuoc: ");
            double soNuoc = Double.parseDouble(nhap.readLine());
            System.out.print("Chon doi tuong\nNhap 1: Doi tuong sinh hoat.\nNhap 2: Doi tuong khong sinh hoat\n");
            int doiTuong = Integer.parseInt(nhap.readLine());
            if (doiTuong != 1 || doiTuong != 2) {
                throw new ArithmeticException("Nhap doi tuong khong dung");
            }
            double[] tongTien = new double[4];
            switch (doiTuong) {
                case 1: {
                    System.out.print("Nhap so nguoi trong ho gia dinh: ");
                    int soNguoi = Integer.parseInt(nhap.readLine());
                    tongTien = tinhTien(soNuoc, soNguoi);
                    System.out.println("So m3 su dung: " + soNuoc);
                    xuatKetQua(tongTien);
                }
                break;
                case 2: {
                    System.out.println("Chon loai:");
                    System.out.println("Nhap 1: Don vi san xuat");
                    System.out.println("Nhap 2: Co quan, doan the, HC su nghiep");
                    System.out.println("Nhap 3: Don vi kinh doanh, dich vu");
                    int loai = Integer.parseInt(nhap.readLine());
                    if (loai != 1 || loai != 2 || loai != 3) {
                        throw new ArithmeticException("Nhap loai khong hop le");
                    }
                    tongTien = tinhTienKhongSH(soNuoc, loai);
                    System.out.println("So m3 su dung: " + soNuoc);
                    xuatKetQua(tongTien);
                }
                break;
                default:
                    System.out.println("Chon doi tuong khong hop le");
                    break;
            }
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
