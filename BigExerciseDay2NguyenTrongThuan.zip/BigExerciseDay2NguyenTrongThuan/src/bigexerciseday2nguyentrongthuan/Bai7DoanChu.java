/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7DoanChu {

    /**
     * @param args the command line arguments
     */
    public static String timTu(int viTri, String[] mang) {
        String kq = "";
        switch (viTri) {
            case 1:
                kq = mang[1];
                break;
            case 2:
                kq = mang[1];
                break;
            case 3:
                kq = mang[2];
                break;
            case 4:
                kq = mang[3];
                break;
            case 5:
                kq = mang[4];
                break;
            case 6:
                kq = mang[5];
                break;
            case 7:
                kq = mang[6];
                break;
            case 8:
                kq = mang[7];
                break;
            case 9:
                kq = mang[8];
                break;
            case 10:
                kq = mang[9];
                break;
            default:
                System.out.println("Ban chon vi tri tu can doan khong hop le");
                break;
        }
        return kq;
    }

    public static int demKiTu(String tuCanDoan, String kiTu) {
        int dem = 0;
        for (int i = 0; i < tuCanDoan.length(); i++) {
            if (kiTu.equalsIgnoreCase(tuCanDoan.charAt(i) + "")) {
                dem++;
            }
        }
        return dem;
    }

    public static String hienThiTu(String tuCanDoan, String kiTu) {
        String kq = "";
        for (int i = 0; i < tuCanDoan.length(); i++) {
            if (!kiTu.equalsIgnoreCase(tuCanDoan.charAt(i) + "")) {
                kq += "*";
            } else {
                kq += tuCanDoan.charAt(i) + "";
            }
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        String[] mang = {"program", "developer", "testing", "coder", "algorithm", "bug", "console", "user", "system", "application"};
        int soLan = 0;
        int stop = 0;
        String tuCanDoan = "";
        try {
            System.out.println("Co 10 tu, ban muon doan tu thu may ? ");
            int viTri = Integer.parseInt(nhap.readLine());
            tuCanDoan = timTu(viTri, mang);
            System.out.println("Tu can doan co " + tuCanDoan.length() + " tu!");
            do {
                soLan++;
                System.out.print("Ban doan trong tu co ky tu: ");
                String kiTu = nhap.readLine();
                int dem = demKiTu(tuCanDoan, kiTu);
                if (dem != 0) {
                    System.out.println("Trong tu co " + dem + " ky tu " + kiTu + ": " + hienThiTu(tuCanDoan, kiTu));
                } else {
                    System.out.println("Xin loi khong co ky tu nay trong o chu");
                }
            } while (stop == 0);

        } catch (NumberFormatException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
}
