/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4DiemSV {

    /**
     * @param args the command line arguments
     */
    public static double tinhDiemTB(double[] a) {
        double kq = 0;
        for (double value : a) {
            kq += value;
        }
        kq = kq / a.length;
        return kq;
    }

    public static double timDiemCaoNhat(double[] a) {
        double kq = a[0];
        for (int i = 1; i < a.length; i++) {
            if (a[i] > kq) {
                kq = a[i];
            }
        }
        return kq;
    }

    public static double timDiemThapNhat(double[] a) {
        double kq = a[0];
        for (int i = 1; i < a.length; i++) {
            if (a[i] < kq) {
                kq = a[i];
            }
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so sinh vien: ");
            int n = Integer.parseInt(nhap.readLine());
            if (n <= 0) {
                throw new ArithmeticException("So luong sinh vien khong hop le");
            }
            double[] diem = new double[n];
            double tam = 0;
            for (int i = 0; i < diem.length; i++) {
                do {
                    System.out.print("Nhap diem sinh vien thu " + (i + 1) + ": ");
                    tam = Double.parseDouble(nhap.readLine());
                } while (tam < 0 || tam > 10);
                diem[i] = tam;

            }
            System.out.println("Diem trung binh cua sinh vien: " + tinhDiemTB(diem));
            System.out.println("Diem cao nhat: " + timDiemCaoNhat(diem));
            System.out.println("Diem thap nhat: " + timDiemThapNhat(diem));
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
