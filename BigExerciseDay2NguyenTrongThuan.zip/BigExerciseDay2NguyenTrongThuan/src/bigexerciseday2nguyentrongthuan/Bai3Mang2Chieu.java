/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3Mang2Chieu {

    /**
     * @param args the command line arguments
     */
    public static void xuatMang(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println("\n");
        }
    }

    public static void sapXep(int[][] a, int n) {
        int tam = 0;
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i][n] > a[j][n]) {
                    tam = a[i][n];
                    a[i][n] = a[j][n];
                    a[j][n] = tam;
                }
            }
        }
    }

    public static double tinhTong(int[][] a) {
        double kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i % 2 == 0 && j % 2 != 0) {
                    kq += a[i][j];
                }
            }

        }
        return kq;
    }

    public static boolean kiemTraSoNT(int n) {
        if (n <= 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void thayGiaTtri(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (kiemTraSoNT(a[i][j])) {
                    a[i][j] = -1;
                }
            }

        }
    }

    public static double tinhTongDongDau(int[][] a) {
        double kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0) {
                    kq += a[i][j];
                }
            }
        }
        return kq;
    }
    
    public static double tinhTongDongCuoi(int[][] a) {
        double kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == a.length - 1) {
                    kq += a[i][j];
                }
            }
        }
        return kq;
    }

    public static double tinhTongCotDau(int[][] a) {
        double kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (j == 0) {
                    kq += a[i][j];
                }
            }
        }
        return kq;
    }
    
    public static double tinhTongCotCuoi(int[][] a) {
        double kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (j == a[i].length - 1) {
                    kq += a[i][j];
                }
            }
        }
        return kq;
    }

    public static boolean kiemTraSoChinhPhuong(int n) {
        if (n <= 0) {
            return false;
        }
        return Math.sqrt(n) == (int) Math.sqrt(n);
    }

    public static String timSoChinhPhuong(int[][] a) {
        String kq = "";
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (kiemTraSoChinhPhuong(a[i][j])) {
                    kq += a[i][j] + " nam o vi tri " + "(" + i + ", " + j + ")\n";
                }
            }
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so dong: ");
            int dong = Integer.parseInt(nhap.readLine());
            System.out.print("Nhap so cot: ");
            int cot = Integer.parseInt(nhap.readLine());
            if(dong <= 0 || cot <= 0){
                throw new ArithmeticException("Nhap kich thuoc mang khong dung");
            }
            int[][] a = new int[dong][cot];
            System.out.println("Nhap gia tri cho mang: ");
            for (int i = 0; i < dong; i++) {
                for (int j = 0; j < cot; j++) {
                    a[i][j] = Integer.parseInt(nhap.readLine());
                }
            }
            System.out.println("Mang vua nhap la: ");
            xuatMang(a);
            System.out.print("Nhap vao stt cot can sap xep: ");
            int n = Integer.parseInt(nhap.readLine());
            System.out.println("\nMang sau khi sap xep la: ");
            sapXep(a, n);
            xuatMang(a);
            System.out.println("Tong cac phan tu dong chan cot le la: " + tinhTong(a));
            thayGiaTtri(a);
            System.out.println("Mang sau khi thay cac phan tu la nguyen to thanh -1:");
            xuatMang(a);
            System.out.println("Tong cac phan tu dong dau tien la: " + tinhTongDongDau(a));
            System.out.println("Tong cac phan tu dong cuoi cung la: " + tinhTongDongCuoi(a));
            System.out.println("Tong cac phan tu cot dau tien la: " + tinhTongCotDau(a));
            System.out.println("Tong cac phan tu cot cuoi dung la: " + tinhTongCotCuoi(a));
            
            String soChinhPhuong = timSoChinhPhuong(a);
            if (soChinhPhuong.length() < 1) {
                System.out.println("Mang khong co so chinh phuong");
            } else {
                System.out.println("So chinh phuong trong mang: ");
                System.out.println(soChinhPhuong);
            }
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
