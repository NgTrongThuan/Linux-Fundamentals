/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1CuocEMS {

    enum EMS1 {
        NOITINH(8000, 8000, 10000, 12500, 15000, 18000, 21000, 1600),
        VUNG1(8500, 12500, 16500, 23500, 33000, 40000, 48500, 3800),
        VUNG21(9500, 13500, 20000, 26500, 38500, 49500, 59500, 8500),
        VUNG22(9500, 13500, 21500, 2800, 40500, 52500, 63500, 8500),
        VUNG3(10000, 14000, 22500, 29500, 43500, 55500, 67500, 9500);

        private double giaBac1;
        private double giaBac2;
        private double giaBac3;
        private double giaBac4;
        private double giaBac5;
        private double giaBac6;
        private double giaBac7;
        private double giaBac8;

        private EMS1(double giaBac1, double giaBac2, double giaBac3, double giaBac4,
                double giaBac5, double giaBac6, double giaBac7, double giaBac8) {
            this.giaBac1 = giaBac1;
            this.giaBac2 = giaBac2;
            this.giaBac3 = giaBac3;
            this.giaBac4 = giaBac4;
            this.giaBac5 = giaBac5;
            this.giaBac6 = giaBac6;
            this.giaBac7 = giaBac7;
            this.giaBac8 = giaBac8;

        }

        public double getGiaBac1() {
            return giaBac1;
        }

        public double getGiaBac2() {
            return giaBac2;
        }

        public double getGiaBac3() {
            return giaBac3;
        }

        public double getGiaBac4() {
            return giaBac4;
        }

        public double getGiaBac5() {
            return giaBac5;
        }

        public double getGiaBac6() {
            return giaBac6;
        }

        public double getGiaBac7() {
            return giaBac7;
        }

        public double getGiaBac8() {
            return giaBac8;
        }

        public double tinhTien(double trongLuong) {
            double kq = 0;

            if (trongLuong <= 50) {
                kq = this.giaBac1;
            } else if (trongLuong <= 100) {
                kq = this.giaBac2 + this.giaBac1;
            } else if (trongLuong <= 250) {
                kq = this.giaBac3 + this.giaBac2 + this.giaBac1;
            } else if (trongLuong <= 500) {
                kq = this.giaBac4 + this.giaBac3 + this.giaBac2
                        + this.giaBac1;
            } else if (trongLuong <= 1000) {
                kq = this.giaBac5 + this.giaBac4 + this.giaBac3
                        + this.giaBac2 + this.giaBac1;
            } else if (trongLuong <= 1500) {
                kq = this.giaBac6 + this.giaBac5 + this.giaBac4
                        + this.giaBac3 + this.giaBac2 + this.giaBac1;
            } else if (trongLuong <= 2000) {
                kq = this.giaBac7 + this.giaBac6 + this.giaBac5
                        + this.giaBac4 + this.giaBac3 + this.giaBac2 + this.giaBac1;
            } else {
                kq = Math.ceil((trongLuong - 2000) / 500) * this.giaBac8 + this.giaBac7 + this.giaBac6 + this.giaBac5 + this.giaBac4 + this.giaBac3 + this.giaBac2 + this.giaBac1;
            }
            return kq;
        }
    }

    enum EMS2 {
        NOITINH(50000, 5000),
        VUNG1(70000, 7000),
        VUNG21(110000, 12000),
        VUNG22(130000, 20000);
        private double giaBac1;
        private double giaBac2;

        private EMS2(double giaBac1, double giaBac2) {
            this.giaBac1 = giaBac1;
            this.giaBac2 = giaBac2;
        }

        public double getGiaBac1() {
            return giaBac1;
        }

        public double getGiaBac2() {
            return giaBac2;
        }

        public double tinhTien(double trongLuong) {
            double kq = 0;
            if (trongLuong <= 2000) {
                kq = this.giaBac1;
            } else {
                kq = Math.ceil((trongLuong - 2000) / 500) * this.giaBac2 + this.giaBac1;
            }
            return kq;
        }

    }

    enum EMS3 {
        NOITINH(50000, 5000),
        VUNG1(70000, 7000),
        VUNG21(85000, 10000),
        VUNG22(100000, 12000),
        VUNG3(110000, 15000);
        private double giaBac1;
        private double giaBac2;

        private EMS3(double giaBac1, double giaBac2) {
            this.giaBac1 = giaBac1;
            this.giaBac2 = giaBac2;
        }

        public double getGiaBac1() {
            return giaBac1;
        }

        public double getGiaBac2() {
            return giaBac2;
        }

        public double tinhTien(double trongLuong) {
            double kq = 0;
            if (trongLuong <= 2000) {
                kq = this.giaBac1;
            } else {
                kq = Math.ceil((trongLuong - 2000) / 500) * this.giaBac2 + this.giaBac1;
            }
            return kq;
        }

    }

    public static double tinhCuocEMS1(double trongLuong, int ems, int vung) {
        if (trongLuong <= 0) {
            throw new ArithmeticException("Nhap trong luong khong hop le");
        }
        double kq = 0;
        EMS1 ems1 = null;
        switch (ems) {
            case 1: {
                kq = ems1.NOITINH.tinhTien(trongLuong);
            }
            break;
            case 2: {
                if (vung == 1) {
                    kq = ems1.VUNG1.tinhTien(trongLuong);
                } else if (vung == 21) {
                    kq = ems1.VUNG21.tinhTien(trongLuong);
                } else if (vung == 22) {
                    kq = ems1.VUNG22.tinhTien(trongLuong);
                } else {
                    kq = ems1.VUNG3.tinhTien(trongLuong);
                }
            }
            break;
            default:
                System.out.println("Chon EMS khong dung");
                break;
        }
        return kq;
    }

    public static double tinhCuocEMS2(double trongLuong, int ems, int vung) {
        if (trongLuong <= 0) {
            throw new ArithmeticException("Nhap trong luong khong hop le");
        }
        double kq = 0;
        EMS2 ems2 = null;
        switch (ems) {
            case 1: {
                kq = ems2.NOITINH.tinhTien(trongLuong);
            }
            break;
            case 2: {
                if (vung == 1) {
                    kq = ems2.VUNG1.tinhTien(trongLuong);
                } else if (vung == 21) {
                    kq = ems2.VUNG21.tinhTien(trongLuong);
                } else {
                    kq = ems2.VUNG22.tinhTien(trongLuong);
                }

            }
            break;
            default:
                System.out.println("Chon EMS khong dung");
                break;
        }
        return kq;
    }

    public static double tinhCuocEMS3(double trongLuong, int ems, int vung) {
        if (trongLuong <= 0) {
            throw new ArithmeticException("Nhap trong luong khong hop le");
        }
        double kq = 0;
        EMS3 ems3 = null;
        switch (ems) {
            case 1: {
                kq = ems3.NOITINH.tinhTien(trongLuong);
            }
            break;
            case 2: {
                if (vung == 1) {
                    kq = ems3.VUNG1.tinhTien(trongLuong);
                } else if (vung == 21) {
                    kq = ems3.VUNG21.tinhTien(trongLuong);
                } else if (vung == 22) {
                    kq = ems3.VUNG22.tinhTien(trongLuong);
                } else {
                    kq = ems3.VUNG3.tinhTien(trongLuong);
                }

            }
            break;
            default:
                System.out.println("Chon EMS khong dung");
                break;
        }
        return kq;
    }

    public static double tinhCuoc(double trongLuong, int hinhThuc, int ems, int vung) {
        if (trongLuong <= 0) {
            throw new ArithmeticException("Nhap trong luong khong hop le");
        }
        double tongTien = 0;
        switch (hinhThuc) {
            case 1:
                tongTien = tinhCuocEMS1(trongLuong, ems, vung);
                break;
            case 2:
                tongTien = tinhCuocEMS2(trongLuong, ems, vung);
                break;
            case 3:
                tongTien = tinhCuocEMS3(trongLuong, ems, vung);
                break;
            default:
                System.out.println("Chon khong dung hinh thuc");
                break;
        }
        return tongTien;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Trong luong buu pham (gr): ");
            double trongLuongBP = Double.parseDouble(nhap.readLine());
            System.out.print("Chon hinh thuc gui:\nNhap 1: Hinh thuc 1\nNhap 2: Hinh thuc 2\nNhap 3: Hinh thuc 3\n");
            int chon = Integer.parseInt(nhap.readLine());
            System.out.print("Chon EMS:\nNhap 1: Noi tinh\nNhap 2: Lien Tinh\n");
            int ems = Integer.parseInt(nhap.readLine());
            int vung = 0;
            if (ems == 2) {
                System.out.print("Chon vung: \nNhap 1: Vung 1\nNhap 21: DaNang-TPHCM,HN\nNhap 22: HN-TPHCM\nNhap 3: Vung 3\n");
                vung = Integer.parseInt(nhap.readLine());
            }
            double tongTien = tinhCuoc(trongLuongBP, chon, ems, vung);
            System.out.println("So tien thanh toan: " + tongTien);
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
}
