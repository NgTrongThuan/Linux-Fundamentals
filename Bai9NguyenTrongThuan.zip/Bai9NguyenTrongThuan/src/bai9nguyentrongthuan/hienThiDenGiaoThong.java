/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class hienThiDenGiaoThong {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        for (DenGiaoThong d : DenGiaoThong.values()) {
            System.out.println("Den " + d.name() + " sau " + d.getSoGiay() + " giay chuyen sang den " + d.chuyenden());
        }
    }

    enum DenGiaoThong {
        DO(30) {
            @Override
            public DenGiaoThong chuyenden() {
                return XANH;
            }
        },
        VANG(10) {
            @Override
            public DenGiaoThong chuyenden() {
                return DO;
            }
        },
        XANH(30) {
            @Override
            public DenGiaoThong chuyenden() {
                return VANG;
            }
        };

        private DenGiaoThong(int soGiay) {
            this.SoGiay = soGiay;
        }

        public abstract DenGiaoThong chuyenden();

        private final int SoGiay;

        public int getSoGiay() {
            return SoGiay;
        }
    }

}
