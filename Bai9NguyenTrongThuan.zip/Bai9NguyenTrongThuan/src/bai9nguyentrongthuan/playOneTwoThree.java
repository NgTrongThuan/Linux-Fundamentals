/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class playOneTwoThree {

    enum OneTwoThree {
        SCISSOR(1), PAPER(2), STONE(3);
        private int rank;

        private OneTwoThree(int rank) {
            this.rank = rank;
        }

        public int getrank() {
            return this.rank;
        }

    }

    static int playtimes = 0;
    static int playermark = 0;
    static int computermark = 0;

    public static String playOneTwoThree(int rankPlayer, int rankComputer) {
        String ketQua = "";
        playtimes++;
        if (rankPlayer == rankComputer) {
            return "Ngang tài ngang sức!";
        } else {
            if (rankPlayer == 1) {
                if (rankComputer == 2) {
                    playermark++;
                    ketQua = "Bạn thắng!";
                }
                if (rankComputer == 3) {
                    computermark++;
                    ketQua = "Bạn thua!";
                }
            }
            if (rankPlayer == 2) {
                if (rankComputer == 1) {
                    computermark++;
                    ketQua = "Bạn thua!";
                }
                if (rankComputer == 3) {
                    playermark++;
                    ketQua = "Bạn thắng!";
                }
            }
            if (rankPlayer == 3) {
                if (rankComputer == 1) {
                    playermark++;
                    ketQua = "Bạn thắng!";
                }
                if (rankComputer == 2) {
                    computermark++;
                    ketQua = "Bạn thua!";
                }
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        boolean cont = true;
        OneTwoThree playermove = null;
        OneTwoThree computermove = null;
        Random random = new Random();
        while (cont) {
            System.out.println("Mời bạn chọn: ");
            System.out.println("- SCISSOR (s) \n- PAPER (p) \n- STONE(t)");
            String player = nhap.readLine();
            int rankPlayer = 0;

            if (player.equals("s")) {
                rankPlayer = playermove.SCISSOR.getrank();
                System.out.println("Your choice: SCISSOR");
            }
            if (player.equals("p")) {
                rankPlayer = playermove.PAPER.getrank();
                System.out.println("Your choice: PAPER");
            }
            if (player.equals("t")) {
                rankPlayer = playermove.STONE.getrank();
                System.out.println("Your choice: STONE");
            }

            int rankComputer = 0;

            rankComputer = random.nextInt(3);

            if (rankComputer == 1) {
                System.out.println("Computer's choice: SCISSOR");
            }
            if (rankComputer == 2) {
                System.out.println("Computer's choice: PAPER");
            }
            if (rankComputer == 3) {
                System.out.println("Computer's choice: STONE");
            }

            System.out.println(playOneTwoThree(rankPlayer, rankComputer));
            if (computermark == 5 || playermark == 5) {
                cont = false;
            }
        }
        System.out.println("---------------------------------------------");
        System.out.println("Times play = " + playtimes);
        System.out.println("Your mark = " + playermark);
        System.out.println("Computer mark = " + computermark);
        if (computermark < playermark) {
            System.out.println("You win !");

        } else {
            System.out.println("Computer win!");
        }
    }
}
