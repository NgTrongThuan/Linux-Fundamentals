/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai9nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhTongHieuTichThuong {

    enum PhepToan {
        TONG,
        HIEU,
        TICH,
        THUONG;

        double tinhToan(double a, double b) {
            switch (this) {
                case TONG:
                    return a + b;
                case HIEU:
                    return a - b;
                case TICH:
                    return a * b;
                case THUONG:
                    if(b == 0) throw new ArithmeticException("Số chia phải khác 0");
                    return a / b;
                default:
                    throw new AssertionError("Unknow operations " + this);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhập số thứ nhất: ");
            int a = Integer.parseInt(nhap.readLine());

            System.out.print("Nhập số thứ hai: ");
            int b = Integer.parseInt(nhap.readLine());

            System.out.println("Tổng hai số vừa nhập: " + PhepToan.TONG.tinhToan(a, b));
            System.out.println("Hiệu hai số vừa nhập: " + PhepToan.HIEU.tinhToan(a, b));
            System.out.println("Tích hai số vừa nhập: " + PhepToan.TICH.tinhToan(a, b));
            System.out.println("Thương hai số vừa nhập: " + PhepToan.THUONG.tinhToan(a, b));
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

}
