/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhBieuThuc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhập x:");
        int x = Integer.parseInt(input.readLine());
        
        double s = 1 + x + pow(x, 3)/3 + pow(x, 5)/5;
        System.out.println("S = 1 + x + x*x*x/3 + x*x*x*x*x/5 = " + s); 
    }
    
}
