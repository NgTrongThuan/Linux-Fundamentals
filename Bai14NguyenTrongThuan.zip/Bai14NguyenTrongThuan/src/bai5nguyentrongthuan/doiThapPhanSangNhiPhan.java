/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class doiThapPhanSangNhiPhan {

    /**
     * @param args the command line arguments
     */
    public static int doiSoThapPhanSangNhiPhanWhile(int n) {
        int ketQua = 0;
        int i = 1;
        int tam = 0;
        while (n > 0) {
            tam = n % 2;
            n /= 2;
            ketQua += tam * i;
            i *= 10;
        }
        return ketQua;
    }

    public static int doiSoThapPhanSangNhiPhanFor(int n) {
        int ketQua = 0;
        int tam = 0;
        int k = 1;
        for (int i = n; i > 0; i /= 2) {
            tam = i % 2;
            ketQua += tam * k;
            k *= 10;
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Chuyển số thập phần sang nhị phân:");
        System.out.println("Sử dụng for: " + n + " = " + doiSoThapPhanSangNhiPhanFor(n));
        System.out.println("Sử dụng while: " + n + " = " + doiSoThapPhanSangNhiPhanWhile(n));
    }

}
