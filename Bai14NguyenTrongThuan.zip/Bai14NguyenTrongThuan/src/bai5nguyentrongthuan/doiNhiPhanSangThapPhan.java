/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class doiNhiPhanSangThapPhan {

    /**
     * @param args the command line arguments
     */
    public static int doiSoNhiPhanSangThapPhanWhile(int n) {
        int ketQua = 0;
        int i = 0;
        int tam = 0;
        while (n > 0) {
            tam = n % 10;
            n /= 10;
            if (tam != 0) {
                ketQua += Math.pow(2, i);
            }
            i++;
        }
        return ketQua;
    }

    public static int doiSoNhiPhanSangThapPhanFor(int n) {
        int ketQua = 0;
        int tam = 0;
        int k = 0;
        for (int i = n; i > 0; i /= 10) {
            tam = i % 10;
            if (tam != 0) {
                ketQua += Math.pow(2, k);
            }
            k++;
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Đổi số nhị phân sang thập phân dùng for: " + n + " = "
                + doiSoNhiPhanSangThapPhanFor(n));
        System.out.println("Đổi số nhị phân sang thập phân dùng while: " + n + " = "
                + doiSoNhiPhanSangThapPhanWhile(n));

    }

}
