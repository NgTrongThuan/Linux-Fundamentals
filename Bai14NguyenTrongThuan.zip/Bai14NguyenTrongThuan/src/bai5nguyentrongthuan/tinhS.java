/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhS {

    /**
     * @param args the command line arguments
     */
    public static double tinhSFor(int n, double x) {
        double s = 1;
        for (int i = 1; i <= Math.abs(n); i++) {
            s *= x * x + 1;
        }
        if (n < 0) {
            s = 1 / s;
        }
        return s;
    }

    public static double tinhSWhile(int n, double x) {
        double s = 1;
        int i = 1;
        while (i <= Math.abs(n)) {
            s *= x * x + 1;
            n++;
        }
        if (n < 0) {
            s = 1 / s;
        }
        return s;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Nhập x: ");
        double x = Double.parseDouble(nhap.readLine());

        System.out.println("Sử dụng for: S = (x * x + 1) mũ n = " + tinhSFor(n, x));
        System.out.println("Sử dụng while: S = (x * x + 1) mũ n = " + tinhSFor(n, x));
    }
}
