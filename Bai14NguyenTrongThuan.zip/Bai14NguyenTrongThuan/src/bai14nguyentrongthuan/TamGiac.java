/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class TamGiac {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public boolean ktTamGiac(int a, int b, int c) {
        boolean kq = (a + b) > c && (b + c) > a && (a + c) > b;
        return kq;
    }

}
