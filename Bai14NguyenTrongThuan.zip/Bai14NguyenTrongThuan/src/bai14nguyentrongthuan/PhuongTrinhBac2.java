/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14nguyentrongthuan;

import jdk.nashorn.internal.objects.Global;

/**
 *
 * @author hocvien
 */
public class PhuongTrinhBac2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }

    public double[] giaiPT(int a, int b, int c) {
        double[] kq = new double[1];
        double delta 
        if (a == 0) {
            if (b == 0) {
                if (c == 0) {
                    kq[0] = Global.Infinity;
                    kq[1] = Global.Infinity;
                }else{
                    kq[0] = Global.NaN;
                    kq[0] = Global.NaN;
                }
            } else {

            }

        } else {

        }
    }
}
