/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TinhSJUnitTest {

    public Bai5TinhSJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testTinhS_1() {
        double ex = 1.0;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(0, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void testTinhS_2() {
        double ex = 1.0;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(1, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void testTinhS_3() {
        double ex = 0.25;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-2, 1);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhS_4() {
        double ex = 0.04;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-2, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhS_5() {
        double ex = 0.1;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-1, 3);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhS_6() {
        double ex = 1.1;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(0, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void testTinhS_7() {
        double ex = 0.9;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(1, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void testTinhS_8() {
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-2, 1);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhS_9() {
        double ex = 0.06;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-2, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhS_10() {
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhS.tinhSFor(-1, 3);
        assertEquals(ex, ac, 0.01);
    }
}
