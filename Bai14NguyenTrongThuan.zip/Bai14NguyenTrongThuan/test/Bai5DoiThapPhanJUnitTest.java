/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5DoiThapPhanJUnitTest {

    public Bai5DoiThapPhanJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testDoiThapPhan_1() {
        int ex = 1100101;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(101);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_2() {
        int ex = 11111110;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(254);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_3() {
        int ex = 1101;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(13);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_4() {
        int ex = 111001;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(57);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_5() {
        int ex = 101011;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(43);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_6() {
        int ex = 1100100;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(101);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_7() {
        int ex = 11111100;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(254);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_8() {
        int ex = 1100;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(13);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_9() {
        int ex = 111000;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(57);
        assertEquals(ex, ac);
    }

    @Test
    public void testDoiThapPhan_10() {
        int ex = 101010;
        int ac = bai5nguyentrongthuan.doiThapPhanSangNhiPhan.doiSoThapPhanSangNhiPhanFor(43);
        assertEquals(ex, ac);
    }
}
