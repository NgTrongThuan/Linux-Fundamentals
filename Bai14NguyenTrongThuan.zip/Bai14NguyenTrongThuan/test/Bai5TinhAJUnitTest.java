/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TinhAJUnitTest {
    
    public Bai5TinhAJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testTinhA_1() {
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(0, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_2() {
        double ex = 9.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(1, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_3() {
        double ex = 55.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(2, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_4() {
        double ex = 0.2;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(-1, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_5() {
        double ex = 370.5;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(3, 2);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void testTinhA_6() {
        double ex = 2.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(0, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_7() {
        double ex = 10.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(1, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_8() {
        double ex = 58.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(2, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_9() {
        double ex = 0.476;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(-1, 2);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testTinhA_10() {
        double ex = 370.0;
        double ac = bai5nguyentrongthuan.tinhA.tinhAFor(3, 2);
        assertEquals(ex, ac, 0.01);
    }
}
