/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14nguyentrongthuan.TamGiac;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TamGiacJUnitTest {

    TamGiac tamGiac = new TamGiac();

    public TamGiacJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void kiemTraTamGiac_1() {
        boolean ac = tamGiac.ktTamGiac(1, 2, 4);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_2() {
        boolean ac = tamGiac.ktTamGiac(2, 3, 4);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_3() {
        boolean ac = tamGiac.ktTamGiac(3, 1, 5);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_4() {
        boolean ac = tamGiac.ktTamGiac(4, 5, 6);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_5() {
        boolean ac = tamGiac.ktTamGiac(10, 5, 20);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_6() {
        boolean ac = tamGiac.ktTamGiac(1, 1, 1);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_7() {
        boolean ac = tamGiac.ktTamGiac(2, 1, 4);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_8() {
        boolean ac = tamGiac.ktTamGiac(5, 10, 8);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_9() {
        boolean ac = tamGiac.ktTamGiac(6, 3, 10);
        assertTrue(ac);
    }

    @Test
    public void kiemTraTamGiac_10() {
        boolean ac = tamGiac.ktTamGiac(2, 4, 5);
        assertTrue(ac);
    }
}
