/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhThucLinh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Số sản phẩm: ");
        int soSanPham = Integer.parseInt(input.readLine());
        
        System.out.println("Tiền công một sản phẩm: ");
        int tienCong = Integer.parseInt(input.readLine());
        
        System.out.println("Tiền thưởng: ");
        int tienThuong = Integer.parseInt(input.readLine());
        
        System.out.println("Số con: ");
        int soCon = Integer.parseInt(input.readLine());
        
        int tienLuong = soSanPham*tienCong;
        System.out.println("Tiền lương: " + tienLuong);
        
        int phuCap = soCon*200000;
        System.out.println("Phụ cấp: " + phuCap);
        
        int thucLinh = tienLuong + tienThuong + phuCap;
        System.out.println("Thực lĩnh: " + thucLinh);
    }
    
}
