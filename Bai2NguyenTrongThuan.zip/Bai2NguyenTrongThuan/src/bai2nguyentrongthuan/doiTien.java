/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author Win7-64 SP1
 */
public class doiTien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Tên ngoại tệ");
        String tenNgoaiTe = input.readLine();
        
        System.out.println("Tỷ giá:");
        int tyGia = Integer.parseInt(input.readLine());
        
        System.out.println("Số ngoại tệ: ");
        int soNgoaiTe = Integer.parseInt(input.readLine());
        
        System.out.println("Bạn đang đổi từ " + tenNgoaiTe + " sang VNĐ:" + tyGia*soNgoaiTe);
    }
    
}
