/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhBanKinh {

    /**
     * @param args the command line arguments
     */
    static final float PI = 3.14f;
    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập vào diện tích hình tròn: ");
        float dienTich = Float.parseFloat(input.readLine());
        System.out.println("Bán kính hình tròn: "+Math.sqrt(dienTich/PI));
    }
}
