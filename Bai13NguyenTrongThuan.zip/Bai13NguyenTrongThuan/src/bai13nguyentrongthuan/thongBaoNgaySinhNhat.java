/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Calendar;

/**
 *
 * @author hocvien
 */
public class thongBaoNgaySinhNhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try{
            System.out.print("Nhap vao ngay sinh nhat: ");
            String ngaySinh = nhap.readLine();
            String[] str = ngaySinh.split("/");
            int ngay = Integer.parseInt(str[0]);
            int thang = Integer.parseInt(str[1]);
           
            LocalDate sinhNhat = LocalDate.of(LocalDate.now().getYear(), thang, ngay);
            Period p = Period.between(sinhNhat, LocalDate.now());
            if(p.getDays() == 0 && p.getMonths() == 0){
                System.out.println("Chuc mung sinh nhat !");
            }else if((p.getDays() < 0 && p.getMonths() == 0 ) || p.getMonths() < 0){
                System.out.println("Vui long doi them...");
                                
            }else{
                System.out.println("Hen sinh nhat nam sau");
            }
        }catch(NumberFormatException ex){
            System.out.print(ex.getMessage());
        }
    }
    
}
