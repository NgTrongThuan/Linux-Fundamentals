/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13nguyentrongthuan;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author hocvien
 */
public class inNgayThangNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calenda = Calendar.getInstance();
        System.out.println("Hom nay la: " + sdf.format(calenda.getTime()));
        System.out.println("Thu: " + calenda.get(Calendar.DAY_OF_WEEK));
        System.out.println("Tuan thu " + calenda.get(Calendar.WEEK_OF_YEAR) + " trong nam");
        Calendar tam = (Calendar)calenda.clone();
        tam.add(Calendar.DAY_OF_WEEK, 7);
        System.out.println("Mot tuan sau la: " + sdf.format(tam.getTime()) );
    }
    
}
