/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai6TongDuongCheoChinhJUnitTest {
    
    public Bai6TongDuongCheoChinhJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTongDuongCheoChinh_1(){
        double ex = 4;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{0,1,2},{1,2,0},{1,0,2}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_2(){
        double ex = 3;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{2,1,0},{0,1,2},{2,1,0}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_3(){
        double ex = 3;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{1,0,2},{1,2,0},{2,1,0}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_4(){
        double ex = 5;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{2,0,1},{2,1,0},{1,0,2}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_5(){
        double ex = 4;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{1,2},{1,3}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_6(){
        double ex = 3;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{0,1,2},{1,2,0},{1,0,2}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_7(){
        double ex = 4;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{2,1,0},{0,1,2},{2,1,0}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_8(){
        double ex = 2;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{1,0,2},{1,2,0},{2,1,0}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_9(){
        double ex = 3;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{2,0,1},{2,1,0},{1,0,2}});
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTongDuongCheoChinh_10(){
        double ex = 3;
        double ac = bai6nguyentrongthuan.xulyMaTranVuong.
                tinhTongDuongCheoChinh(new int[][]{{1,2},{1,3}});
        assertEquals(ex, ac, 0);
    }
}
