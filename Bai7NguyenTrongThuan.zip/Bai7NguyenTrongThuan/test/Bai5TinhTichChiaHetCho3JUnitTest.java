/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TinhTichChiaHetCho3JUnitTest {
    
    public Bai5TinhTichChiaHetCho3JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTinhTichChiaHetCho3_1(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_2(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_3(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_4(){
        double ex = 3;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_5(){
        double ex = 3;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(4);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_6(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_7(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_8(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_9(){
        double ex = 6;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTichChiaHetCho3_10(){
        double ex = 24;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichChiaHetCho3For(4);
        assertEquals(ex, ac, 0);
    }
}
