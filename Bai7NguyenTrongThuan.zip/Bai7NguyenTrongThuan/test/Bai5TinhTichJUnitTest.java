/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5TinhTichJUnitTest {
    
    public Bai5TinhTichJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTinhTich_1(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_2(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_3(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_4(){
        double ex = 6;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_5(){
        double ex = 24;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(4);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_6(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(0);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_7(){
        double ex = 0;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(1);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_8(){
        double ex = 1;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(2);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_9(){
        double ex = 2;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(3);
        assertEquals(ex, ac, 0);
    }
    @Test
    public void testTinhTich_10(){
        double ex = 6;
        double ac = bai5nguyentrongthuan.tinhGTBT.tinhTichFor(4);
        assertEquals(ex, ac, 0);
    }
}
