/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai5DoiSoNhiPhanJUnitTest {

    public Bai5DoiSoNhiPhanJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void TestDoiSoNhiPhan_1() {
        int ex = 101;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(1100101);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_2() {
        int ex = 254;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(11111110);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_3() {
        int ex = 13;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(1101);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_4() {
        int ex = 57;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(111001);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_5() {
        int ex = 43;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(101011);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_6() {
        int ex = 102;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(1100101);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_7() {
        int ex = 253;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(11111110);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_8() {
        int ex = 14;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(1101);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_9() {
        int ex = 58;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(111001);
        assertEquals(ex, ac);
    }

    @Test
    public void TestDoiSoNhiPhan_10() {
        int ex = 44;
        int ac = bai5nguyentrongthuan.doiNhiPhanSangThapPhan.doiSoNhiPhanSangThapPhanFor(101011);
        assertEquals(ex, ac);
    }
}
