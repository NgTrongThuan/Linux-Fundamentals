/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class kiemTraMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static boolean kiemTraMangTangDan(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] > arr[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public static boolean kiemTraMangGiamDan(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] < arr[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public static int timKiemPhanTu(int[] arr) {
        int ketQua = 0;
        for(int value:arr){
            if(value % 10 == 6){
                ketQua = value;
                break;
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập vào n: ");
        int n = Integer.parseInt(nhap.readLine());

        int[] arr = new int[n];
        System.out.println("Nhập vào giá trị các phần tử của mảng");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(nhap.readLine());
        }
        String rs = " ";
        for (int value : arr) {
            rs += value + " ";
        }
        System.out.println("Mảng a vừa tạo: " + rs);

        if (kiemTraMangTangDan(arr)) {
            System.out.println("Mảng a có sắp xếp thứ tự tăng dần");
        } else {
            System.out.println("Mảng a có sắp xếp thứ tự KHÔNG tăng dần");
        }

        if (kiemTraMangGiamDan(arr)) {
            System.out.println("Mảng a có sắp xếp thứ tự giảm dần");
        } else {
            System.out.println("Mảng a có sắp xếp thứ tự KHÔNG giảm dần");
        }
        int ketQua = timKiemPhanTu(arr);
        if(ketQua != 0){
            System.out.println("Phần tử đầu tiên trong mảng có tận cùng là 6 là: " + ketQua);
        }else{
            System.out.println("KHÔNG có phần tử đầu tiên trong mảng có tận cùng là 6 ! ");
        }
    }

}
