/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class xuLyMangHaiChieu {

    /**
     * @param args the command line arguments
     */
    public static int demSoChan(int[][] arr) {
        int dem = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 == 0) {
                    dem++;
                }
            }
        }
        return dem;
    }

    public static int demSoLe(int[][] arr) {
        int dem = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 != 0) {
                    dem++;
                }
            }
        }
        return dem;
    }

    public static double tinhTongSoChan(int[][] arr) {
        double tong = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 == 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static double tinhTongSoLe(int[][] arr) {
        double tong = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 != 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static double tinhTrungBinhSoChan(int[][] arr) {
        double ketQua = 0;
        ketQua = tinhTongSoChan(arr) / demSoChan(arr);
        return ketQua;
    }

    public static double tinhTrungBinhSoLe(int[][] arr) {
        double ketQua = 0;
        ketQua = tinhTongSoLe(arr) / demSoLe(arr);
        return ketQua;
    }

    public static int timPhanTuLonNhat(int[][] arr) {
        int phanTuLonNhat = arr[0][0];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] > phanTuLonNhat) {
                    phanTuLonNhat = arr[i][j];
                }
            }
        }
        return phanTuLonNhat;
    }

    public static int timPhanTuNhoNhat(int[][] arr) {
        int phanTuNhoNhat = arr[0][0];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] < phanTuNhoNhat) {
                    phanTuNhoNhat = arr[i][j];
                }
            }
        }
        return phanTuNhoNhat;
    }

    public static String timViTriCuaPhanTu(int[][] a, int x) {
        String ketQua = "";
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] == x) {
                    ketQua += " nằm ở dòng " + i + " và cột " + j + ", ";
                }
            }
        }
        return ketQua;
    }

    public static int demSoLanXuatHien(int[][] a, int x) {
        int dem = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] == x) {
                    dem++;
                }
            }
        }
        return dem;
    }

    public static int demSoLanXuatHienNhieuNhat(int[][] a) {
        int dem = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (demSoLanXuatHien(a, a[i][j]) > dem) {
                    dem = demSoLanXuatHien(a, a[i][j]);
                }
            }
        }
        return dem;
    }

    public static void timPhanTuXuatHienNhieuNhat(int[][] a) {
        int dem = demSoLanXuatHienNhieuNhat(a);
        int tam = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] != tam) {
                    if (demSoLanXuatHien(a, a[i][j]) == dem) {
                        System.out.println("Số " + a[i][j] + " nằm ở dòng " + i + " và cột " + j);
                    }
                }
            }
        }
    }

    public static boolean kiemTraPhanTuAm(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] < 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập số dòng n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Nhập số cột m: ");
        int m = Integer.parseInt(nhap.readLine());

        int[][] arr = new int[n][m];
        System.out.println("Nhập giá trị cho phần tử mảng 2 chiều: ");
        for (int i = 0; i < n; i++) {
            System.out.println("Nhập dòng thứ " + i + ":");
            for (int j = 0; j < m; j++) {
                System.out.print("   Nhập cột thứ " + j + ": ");
                arr[i][j] = Integer.parseInt(nhap.readLine());
            }
        }

        System.out.println("**********************************");
        System.out.println("Mảng hai chiều vừa nhập:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.print("\n");
        }
        System.out.println("**********************************");
        System.out.println("Số phần tử chẵn của mảng là: " + demSoChan(arr));
        System.out.println("Số phần tử lẻ của mảng là: " + demSoLe(arr));
        System.out.println("Giá trị trung bình các phần tử chẵn: " + tinhTrungBinhSoChan(arr));
        System.out.println("Giá trị trung bình các phần tử lẻ: " + tinhTrungBinhSoLe(arr));
        int phanTuLonNhat = timPhanTuLonNhat(arr);
        int phanTuNhoNhat = timPhanTuNhoNhat(arr);
        System.out.println("Phần tử lớn nhất là: " + phanTuLonNhat + timViTriCuaPhanTu(arr, phanTuLonNhat));
        System.out.println("Phần tử nhỏ nhất là: " + phanTuNhoNhat + timViTriCuaPhanTu(arr, phanTuNhoNhat));
        if (kiemTraPhanTuAm(arr)) {
            System.out.println("Ma trận có phần tử âm !");
        } else {
            System.out.println("Ma trận không có phần tử âm !");
        }
        System.out.println("Phần tử xuất hiện nhiều nhất và vị trí :");
        timPhanTuXuatHienNhieuNhat(arr);
    }

}
