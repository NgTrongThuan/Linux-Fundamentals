/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhBMI {

    /**
     * @param args the command line arguments
     */
    public static double tinhBMI(double canNang, double ChieuCao){
        return canNang / (ChieuCao * ChieuCao);
    }
    
    public static String danhGiaBMI(double BMI){
        String ketQua = "";
        if(BMI < 18.5){
            ketQua = "Gầy";
        }else if(BMI <= 24.99){
            ketQua = "Bình thường";
        }else{
            ketQua = "Thừa cân";
        }
        return ketQua;
    }
    
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Nhập chiều cao: ");
        double chieuCao = Double.parseDouble(nhap.readLine());
        
        System.out.print("Nhập cân nặng: ");
        double canNang = Double.parseDouble(nhap.readLine());
        
        System.out.println(danhGiaBMI(tinhBMI(canNang, chieuCao)));
    }
    
}
