/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhGiaiThua {

    /**
     * @param args the command line arguments
     */
    public static boolean kiemTraChanLe(int n) {
        if (n % 2 != 0) {
            return false;
        }
        return true;
    }

    public static int tinhGiaiThuaFor(int n) {
        int giaiThua = 1; // n = 0
        for (int i = 1; i <= n; i++) {
            giaiThua *= i;
        }
        return giaiThua;
    }

    public static int tinhGiaiThuaWhile(int n) {
        int giaiThua = 1; // n = 0
        while (n > 0) {
            giaiThua *= n;
            n--;
        }
        return giaiThua;
    }

    public static int tinhTichSoChan(int n) {
        int tich = 1;
        if (n < 2) {
            tich = 0;
        }
        for (int i = 2; i <= n; i += 2) {
            tich *= i;
        }
        return tich;
    }

    public static int tinhTichSoLe(int n) {
        int tich = 1;
        if (n == 0) {
            tich = 0;
        }
        for (int i = 1; i <= n; i += 2) {
            tich *= i;
        }
        return tich;
    }

    public static int tinhGiaTriFor(int n) {
        int ketQua = 0;

        if (kiemTraChanLe(n)) {
            ketQua = tinhTichSoChan(n);
        } else {
            ketQua = tinhTichSoLe(n);
        }
        return ketQua;
    }

    public static int tinhGiaTriWhile(int n) {
        int ketQua = 1;
        int i = 2;
        int j = 1;
        if (kiemTraChanLe(n)) {
            while (i <= n) {
                ketQua *= i;
                i += 2;
            }
        } else {
            while (j <= n) {
                ketQua *= j;
                j += 2;
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Sử dụng for:");
        System.out.println(n + " != " + tinhGiaiThuaFor(n));
        System.out.println(n + " !!= " + tinhGiaTriFor(n));

        System.out.println("Sử dụng while:");
        System.out.println(n + " != " + tinhGiaiThuaWhile(n));
        System.out.println(n + " !!= " + tinhGiaTriWhile(n));
    }

}
