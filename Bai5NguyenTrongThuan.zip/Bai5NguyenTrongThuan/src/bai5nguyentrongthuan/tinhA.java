/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhA {

    /**
     * @param args the command line arguments
     */
    public static double tinhAFor(int n, int x) {
        double a = 0;
        double a1 = 1; //n = 0 => biểu thức đầu tiên bằng 0
        double a2 = 1; // n = 0 => biểu thức thứ 2 bằng 0

        for (int i = 1; i <= n; i++) {
            a1 *= x * x + x + 1;
            a2 *= x * x - x + 1;
        }
        a = a1 + a2;
        return a;
    }

    public static double tinhAWhile(int n, int x) {
        double a = 0;
        double a1 = 1; //n = 0 => biểu thức đầu tiên bằng 0
        double a2 = 1; // n = 0 => biểu thức thứ 2 bằng 0
        int i = 1;
        while (i <= n) {
            a1 *= x * x + x + 1;
            a2 *= x * x - x + 1;
            i++;
        }
        a = a1 + a2;
        return a;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        System.out.println("Nhập x: ");
        int x = Integer.parseInt(nhap.readLine());

        System.out.println("Sử dụng for: A = (x * x + x + 1) mũ n + (x * x - x + 1) mũ n = " + tinhAFor(n, x));
        System.out.println("Sử dụng while: A = (x * x + x + 1) mũ n + (x * x - x + 1) mũ n = " + tinhAWhile(n, x));
    }

}
