/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timCapSoMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static void inCapSoChiaHet(int[] arr, int n) {
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if ((arr[i] % arr[j] == 0) || (arr[j] % arr[i] == 0)) {
                    System.out.println(arr[i] + "&" + arr[j]);
                }
            }
        }
    }

    public static void inCapSoGapDoi(int[] arr, int n) {
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if ((arr[i] * 2 == arr[j]) || (arr[j] * 2 == arr[i])) {
                    System.out.println(arr[i] + "&" + arr[j]);
                }
            }
        }
    }

    public static void inCapSoTongBang8(int[] arr, int n) {
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if ((arr[i] + arr[j] == 8) || (arr[j] + arr[i] == 8)) {
                    System.out.println(arr[i] + "&" + arr[j]);
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n: ");
        int n = Integer.parseInt(nhap.readLine());

        int[] arr = new int[n];
        System.out.println("Nhập vào giá trị phần tử của mảng: ");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(nhap.readLine());
        }

        System.out.println("Cặp số có quan hệ chia hết:");
        inCapSoChiaHet(arr, n);
        System.out.println("Cặp số có quan hệ gấp đôi:");
        inCapSoGapDoi(arr, n);
        System.out.println("Cặp số có tổng bằng 8:");
        inCapSoTongBang8(arr, n);

    }

}
