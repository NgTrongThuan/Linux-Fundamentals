/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timKiemTrongMang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n:");
        int n = Integer.parseInt(nhap.readLine());
        int[] arr = new int[n];

        System.out.println("Nhập giá trị cho các phần tử trong mảng:");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(nhap.readLine());
        }

        System.out.println("Nhập x:");
        int x = Integer.parseInt(nhap.readLine());

        String rs = " ";
        for (int value : arr) {
            rs += value + " ";
        }
        System.out.println("Mảng đã nhập:" + rs);

        for (int i = 0; i < n; i++) {
            if (arr[i] == x) {
                System.out.println(x + " xuất hiện trong mảng tại vị trí thứ " + i);
            }else{
                System.out.println(x + " không xuất hiện trong mảng");
                break;
            }
        }
        
        boolean kiemTra = true;
        String tam = " ";
        for (int value : arr) {
            if(x < value){
                kiemTra = false;
                tam += value + " ";
            }
        }
        if(!kiemTra){
            System.out.println(x + " không lớn hơn tất cả các số trong mảng ");
        }
        System.out.println("Tất cả các số lớn hơn " + x + " là " + tam);
    }
}
