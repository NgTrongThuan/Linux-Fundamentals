/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class soSanhStringBuilderTuCharVaString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        
        long t1 = System.currentTimeMillis();
        
        for (int i = 0; i < 1000000; i++) {
            sb1.append('A');
        }
        
        long t2 = System.currentTimeMillis();
        
        for(int i = 0; i < 1000000; i++){
            sb2.append("A");
        }
        
        long t3 = System.currentTimeMillis();
        
        long thoiGianSB1 = t2 - t1;
        long thoiGianSB2 = t3 - t2;
        
        System.out.println("Chiều dài chuỗi String sb1: " + sb1.length());
        System.out.println("Chiều dài chuỗi String sb2: " + sb2.length());
        System.out.println("Thời gian thực hiện sb1: " + thoiGianSB1 + " milisecond");
        System.out.println("Thời gian thực hiện sb2: " + thoiGianSB2 + " milisecond");
        if(thoiGianSB1 > thoiGianSB2){
            System.out.println("Thời gian thêm char dài hơn String");
        }else{
            System.out.println("Thời gian thêm String dài hơn char");
        }
    }

}
