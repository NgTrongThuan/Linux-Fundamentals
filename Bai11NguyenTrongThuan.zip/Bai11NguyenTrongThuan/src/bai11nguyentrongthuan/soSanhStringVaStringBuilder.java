/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

/**
 *
 * @author hocvien
 */
public class soSanhStringVaStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s = "";
        StringBuilder sb = new StringBuilder();
        long t1 = System.currentTimeMillis();
        for (int i = 1; i <= 10000; i++) {
            s += i + " ";
        }
        long t2 = System.currentTimeMillis();
        for (int i = 1; i <= 10000; i++) {
            sb.append(i + " ");
        }
        long t3 = System.currentTimeMillis();
        System.out.println("Chiều dài chuỗi String s: " + s.length());
        System.out.println("Chiều dài chuỗi String sb: " + sb.length());
        long thoiGianS = t2 - t1;
        long thoiGianSB = t3 - t2;
        System.out.println("Thời gian thực hiện s: " + thoiGianS + " milisecond");
        System.out.println("Thời gian thực hiện sb: " + thoiGianSB + " milisecond");
        if(thoiGianS > thoiGianSB){
            System.out.println("Thời gian s dài hơn sb.");
        }else{
            System.out.println("Thời gian sb dài hơn s.");
        }
    }

}
