/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class xuLyChuoiStringBuilder2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhập nguồn sb: ");
            StringBuffer sb = new StringBuffer(nhap.readLine());
            for (int i = 0; i < sb.length(); i++) {
                System.out.println(sb.charAt(i));
            }
            System.out.print("Nhập vào chuỗi kt: ");
            String kt = nhap.readLine();
            int viTri = sb.indexOf(kt);
            if (viTri >= 0) {
                System.out.println("Chuỗi vừa nhập ở vị trí: " + viTri);
            } else {
                System.out.println("Không tìm thấy chuỗi");
            }
        } catch (NullPointerException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
