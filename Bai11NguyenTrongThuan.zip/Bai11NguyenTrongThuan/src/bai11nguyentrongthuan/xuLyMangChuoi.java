/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class xuLyMangChuoi {

    /**
     * @param args the command line arguments
     */
    public static int timTen(String[] mangTen, String ten) {
        int ketQua = 0;
        for (int i = 0; i < mangTen.length; i++) {
            if (ten.compareTo(mangTen[i]) == 0) {
                ketQua = i;
                break;
            }
        }
        return ketQua;
    }

    public static String timPhanTu(String[] mangTen, String n) {
        String ketQua = "";
        for (String value : mangTen) {
            if (value.indexOf(n) >= 0) {
                ketQua += value + " , ";
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập số nguyên dương n: ");
            int n = Integer.parseInt(nhap.readLine());
            if (n <= 0) {
                throw new ArithmeticException("Kích thước mảng phải lớn hơn 0");
            }

            String[] mangTen = new String[n];
            System.out.println("Nhập giá trị cho mảng tên: ");
            for (int i = 0; i < mangTen.length; i++) {
                System.out.print("Nhập giá trị thứ " + i + " : ");
                mangTen[i] = nhap.readLine();
            }
            System.out.println("Mảng tên vừa nhập: ");
            for (String value : mangTen) {
                System.out.print(value + " , ");
            }

            System.out.print("\nNhập tên người muốn tìm: ");
            String ten = nhap.readLine();

            int ketQua = timTen(mangTen, ten);
            if (ketQua != 0) {
                System.out.println("Trong mảng có tên " + ten + " nằm ở vị trí " + ketQua);
            } else {
                System.out.println("Tên vừa nhập không xuất hiện trong mảng");
            }
            System.out.print("Nhập vào kí tự: ");
            String kiTu = nhap.readLine();
            String phanTu = timPhanTu(mangTen, kiTu);
            if (phanTu.isEmpty()) {
                System.out.println("Không có tên nào xuất hiện kí tự vừa nhập !");
            } else {
                System.out.println("Tên có kí tự " + kiTu + " là: " + phanTu);
            }
            
            Arrays.sort(mangTen);
            System.out.println("Mảng tên sau khi được sắp xếp là: ");
            for (String value : mangTen) {
                System.out.print(value + " , ");
            }

        } catch (NumberFormatException | InputMismatchException | ArithmeticException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

}
