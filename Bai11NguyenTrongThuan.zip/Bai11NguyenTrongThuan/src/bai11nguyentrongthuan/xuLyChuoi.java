/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class xuLyChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try{
        System.out.print("Nhập chuỗi s1: ");
        String s1 = nhap.readLine();
        System.out.print("Nhập chuỗi s2: ");
        String s2 = nhap.readLine();
        System.out.print("Nhập chuỗi s3: ");
        String s3 = nhap.readLine();
        System.out.print("Nhập vị trí v: ");
        int v = Integer.parseInt(nhap.readLine());
        System.out.println("Chiều dài chuỗi s1: " + s1.length());
        System.out.println("Chiều dài chuỗi s2: " + s2.length());
        System.out.println("Chiều dài chuỗi s3: " + s3.length());
        System.out.println("Kết quả so sánh s1 & s2: " + s1.equals(s2));
        s1.concat(s2);
        System.out.println("Vị trí xuất hiện đầu tiên của chuỗi s3 trong s1: " + s1.indexOf(s3));
        String s4 = s1.substring(v);
        }catch(NumberFormatException | InputMismatchException ex){
            System.out.println("Error: " + ex.getMessage());
        }
    }
    
}
