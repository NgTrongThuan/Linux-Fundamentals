/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class xuLyChuoiStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập chuỗi sb: ");
            StringBuilder sb = new StringBuilder(nhap.readLine());
            System.out.println("Chiều dài chuỗi sb: " + sb.length());

            System.out.println("Nhập chuỗi sb1: ");
            StringBuilder sb1 = new StringBuilder(nhap.readLine());
            System.out.println("Chiều dài chuỗi sb1: " + sb1.length());

            System.out.println("Nhập chuỗi sb2: ");
            StringBuilder sb2 = new StringBuilder(nhap.readLine());
            System.out.println("Chiều dài chuỗi sb2 " + sb2.length());

            System.out.println("Nhập chuỗi sb3: ");
            StringBuilder sb3 = new StringBuilder(nhap.readLine());
            System.out.println("Chiều dài chuỗi sb3 " + sb3.length());

            System.out.println("Nhập chuỗi sb4: ");
            StringBuilder sb4 = new StringBuilder(nhap.readLine());
            System.out.println("Chiều dài chuỗi sb4 " + sb4.length());

            System.out.println("Nhập vị trí chèn: ");
            int chen = Integer.parseInt(nhap.readLine());
            if(chen < 0 | chen > sb.length()) throw new ArithmeticException("Vị trí chèn không hợp lệ !");

            System.out.println("Nhập vị trí đầu: ");
            int viTriDau = Integer.parseInt(nhap.readLine());
            if (viTriDau < 0 | viTriDau >= sb.length()) {
                throw new ArithmeticException("Vị trí đầu không hợp lệ !");
            }
            System.out.println("Nhập vị trí cuối: ");
            int viTriCuoi = Integer.parseInt(nhap.readLine());
            if (viTriCuoi < 0 | viTriCuoi < viTriDau | viTriCuoi > sb.length()) {
                throw new ArithmeticException("Vị trí cuối không hợp lệ !");
            }
            sb.append(sb1);
            System.out.println("Chuỗi sb sau khi nối chuỗi sb1: " + sb);

            sb.insert(chen, sb2);
            System.out.println("Chuỗi sb sau khi chèn chuỗi sb2: " + sb);

            sb.delete(viTriDau, viTriCuoi);
            System.out.println("Chuỗi sb sau khi xóa nội dung từ vị trí đầu tới vị trí cuối: " + sb);

            sb.reverse();
            System.out.println("Chuỗi sb sau khi bị đảo ngược: " + sb);
        } catch (NumberFormatException | InputMismatchException | ArithmeticException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

}
