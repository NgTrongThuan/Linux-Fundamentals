/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class hienThiMaTranChuoi {

    /**
     * @param args the command line arguments
     */
    public static void xuLyCauA(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i >= j) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "";
                }

            }
        }
    }

    public static void xuLyCauB(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i <= j) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "";
                }

            }
        }
    }

    public static void xuLyCauC(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i <= j) {
                    a[i][j] = "#  ";
                } else {
                    a[i][j] = "   ";
                }

            }
        }
    }

    public static void xuLyCauD(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i + j < a.length - 1) {
                    a[i][j] = "    ";
                } else {
                    a[i][j] = "#   ";
                }

            }
        }
    }

    public static void xuLyCauE(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || j == 0 || j == a.length - 1) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "    ";
                }
            }
        }
    }

    public static void xuLyCauF(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "    ";
                }
            }
        }
    }

    public static void xuLyCauG(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i + j == a.length - 1) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "    ";
                }

            }
        }
    }

    public static void xuLyCauH(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j || i + j == a.length - 1) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "    ";
                }

            }
        }
    }

    public static void xuLyCauI(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j || i + j == a.length - 1 || j == 0 || j == a.length - 1) {
                    a[i][j] = "#   ";
                } else {
                    a[i][j] = "    ";
                }

            }
        }
    }

    public static void inMang(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j]);
            }
            System.out.println("\n");
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhập kích thước ma trận: ");
            int n = Integer.parseInt(nhap.readLine());
            String[][] a = new String[n][n];
            System.out.println("Chọn hình cần in: A B C D E F G H I ?");
            String chon = nhap.readLine();
            switch (chon) {
                case "A":
                    xuLyCauA(a);
                    inMang(a);
                    break;
                case "B":
                    xuLyCauB(a);
                    inMang(a);
                    break;
                case "C":
                    xuLyCauC(a);
                    inMang(a);
                    break;
                case "D":
                    xuLyCauD(a);
                    inMang(a);
                    break;
                case "E":
                    xuLyCauE(a);
                    inMang(a);
                    break;
                case "F":
                    xuLyCauF(a);
                    inMang(a);
                    break;
                case "G":
                    xuLyCauG(a);
                    inMang(a);
                    break;
                case "H":
                    xuLyCauH(a);
                    inMang(a);
                    break;
                case "I":
                    xuLyCauI(a);
                    inMang(a);
                    break;
            }
        } catch (NumberFormatException ex) {
            System.out.println("Error: " + ex.getMessage());
        }

    }

}
