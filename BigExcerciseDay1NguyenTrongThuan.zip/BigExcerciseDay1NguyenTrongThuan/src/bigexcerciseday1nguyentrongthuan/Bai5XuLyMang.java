/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import jdk.internal.org.objectweb.asm.tree.analysis.Value;

/**
 *
 * @author hocvien
 */
public class Bai5XuLyMang {

    public static int[] phatSinhMang(int n){
        int[] kq = new int[n];
        Random random = new Random();
        for(int i = 0; i < n; i++){
            kq[i] = random.nextInt(n);
        }
        return kq;
    }
    
    public static void xuatMang1Chieu(int[] a){
        for(int value : a){
            System.out.print(value + " ");
        }
    }
    
    public static String[][] taoMaTranChuoi(int n, int[] mang){
        String[][] kq = new String[n][n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                if(j == mang[i]){
                    kq[i][j] = "Q";
                }else{
                    kq[i][j] = "*";
                }
            }
        }
        return kq;
    }
    
    public static void xuatMaTranChuoi(String[][] a){
        for(int i = 0; i < a.length; i++){
            for(int j = 0; j < a[i].length; j++){
                System.out.print(a[i][j] + "\t");
            }
            System.out.println("\n");
        }
    }
    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap vao n: ");
            int n = Integer.parseInt(nhap.readLine());
            if (n <= 0) {
                throw new ArithmeticException("Nhap kich thuoc mang khong dung");
            }
            int[] mang = phatSinhMang(n);
            System.out.print("Mang 1 chieu vua phat sinh la: ");
            xuatMang1Chieu(mang);
            
            String[][] maTran = taoMaTranChuoi(n, mang);
            System.out.println("\n--------------------------------");
            System.out.println("Ma tran vua tao la: ");
            xuatMaTranChuoi(maTran);
            
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
