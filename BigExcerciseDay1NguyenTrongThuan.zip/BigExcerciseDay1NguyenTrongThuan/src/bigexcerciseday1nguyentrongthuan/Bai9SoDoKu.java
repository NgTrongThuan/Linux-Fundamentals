/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai9SoDoKu {

    public static boolean kiemTraSoTrung(int[][] a, int x) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (x == a[i][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int[][] taoSoDoKu() {
        int[][] sodoku = new int[9][9];
        Random random = new Random();
        int tam = random.nextInt(10);
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if(!kiemTraSoTrung(sodoku, tam)) {
                    tam = random.nextInt(10);
                }
                sodoku[i][j] = tam;
            }
        }
        return sodoku;
    }

    public static void xuatSoDoKu(int[][] a) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println("\n");
        }
    }

    public static void main(String[] args) {
        int[][] a = taoSoDoKu();
        xuatSoDoKu(a);
    }

}
