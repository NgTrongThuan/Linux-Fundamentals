/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3MuaVe {

    final static double A2T = 129000;
    final static double A2TL = 128000;
    final static double AnLT1 = 249000;
    final static double AnLT2 = 218000;
    final static double AnT1 = 202000;
    final static double AnT2 = 172000;
    final static double BnLT1 = 214000;
    final static double BnLT2 = 189000;
    final static double BnLT3 = 163000;
    final static double BnT1 = 193000;
    final static double BnT2 = 168000;
    final static double BnT3 = 146000;
    final static double GP = 79000;
    final static double NC = 99000;
    final static double NCL = 116000;
    final static double NM = 129000;
    final static double NML = 155000;
    final static double NML4V = 171000;

    public static double[] tinhTien(String loaiGhe, int nguoiLon, int treEm, int nguoiGia) {
        if (nguoiLon < 0 || treEm < 0 || nguoiGia < 0) {
            throw new ArithmeticException("So ve nhap vao khong hop le");
        }
        double[] tongTien = new double[3];
        switch (loaiGhe) {

            case "A2T":
                tongTien[0] = nguoiLon * A2T;
                tongTien[1] = treEm * (A2T * 0.5);
                tongTien[2] = nguoiGia * (A2T * 0.75);
                break;
            case "A2TL":
                tongTien[0] = nguoiLon * A2TL;
                tongTien[1] = treEm * (A2TL * 0.5);
                tongTien[2] = nguoiGia * (A2TL * 0.75);
                break;
            case "AnLT1":
                tongTien[0] = nguoiLon * AnLT1;
                tongTien[1] = treEm * (AnLT1 * 0.5);
                tongTien[2] = nguoiGia * (AnLT1 * 0.75);
                break;
            case "AnLT2":
                tongTien[0] = nguoiLon * AnLT2;
                tongTien[1] = treEm * (AnLT2 * 0.5);
                tongTien[2] = nguoiGia * (AnLT2 * 0.75);
                break;
            case "AnT1":
                tongTien[0] = nguoiLon * AnT1;
                tongTien[1] = treEm * (AnT1 * 0.5);
                tongTien[2] = nguoiGia * (AnT1 * 0.75);
                break;
            case "AnT2":
                tongTien[0] = nguoiLon * AnT2;
                tongTien[1] = treEm * (AnT2 * 0.5);
                tongTien[2] = nguoiGia * (AnT2 * 0.75);
                break;
            case "BnLT1":
                tongTien[0] = nguoiLon * BnLT1;
                tongTien[1] = treEm * (BnLT1 * 0.5);
                tongTien[2] = nguoiGia * (BnLT1 * 0.75);
                break;
            case "BnLT2":
                tongTien[0] = nguoiLon * BnLT2;
                tongTien[1] = treEm * (BnLT2 * 0.5);
                tongTien[2] = nguoiGia * (BnLT2 * 0.75);
                break;
            case "BnLT3":
                tongTien[0] = nguoiLon * BnLT3;
                tongTien[1] = treEm * (BnLT3 * 0.5);
                tongTien[2] = nguoiGia * (BnLT3 * 0.75);
                break;
            case "BnT1":
                tongTien[0] = nguoiLon * BnT1;
                tongTien[1] = treEm * (BnT1 * 0.5);
                tongTien[2] = nguoiGia * (BnT1 * 0.75);
                break;
            case "BnT2":
                tongTien[0] = nguoiLon * BnT2;
                tongTien[1] = treEm * (BnT2 * 0.5);
                tongTien[2] = nguoiGia * (BnT2 * 0.75);
                break;
            case "BnT3":
                tongTien[0] = nguoiLon * BnT3;
                tongTien[1] = treEm * (BnT3 * 0.5);
                tongTien[2] = nguoiGia * (BnT3 * 0.75);
                break;
            case "GP":
                tongTien[0] = nguoiLon * GP;
                tongTien[1] = treEm * (GP * 0.5);
                tongTien[2] = nguoiGia * (GP * 0.75);
                break;
            case "NC":
                tongTien[0] = nguoiLon * NC;
                tongTien[1] = treEm * (NC * 0.5);
                tongTien[2] = nguoiGia * (NC * 0.75);
                break;
            case "NCL":
                tongTien[0] = nguoiLon * NCL;
                tongTien[1] = treEm * (NCL * 0.5);
                tongTien[2] = nguoiGia * (NCL * 0.75);
                break;
            case "NML":
                tongTien[0] = nguoiLon * NML;
                tongTien[1] = treEm * (NML * 0.5);
                tongTien[2] = nguoiGia * (NML * 0.75);
                break;
            case "NML4V":
                tongTien[0] = nguoiLon * NML4V;
                tongTien[1] = treEm * (NML4V * 0.5);
                tongTien[2] = nguoiGia * (NML4V * 0.75);
                break;
            default:
                System.out.println("\nNhap loai ghe khong hop le");
                break;

        }
        return tongTien;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap loai ghe: ");
            String loaiGhe = nhap.readLine().toUpperCase();
            System.out.println("Nhap tong so ve: ");
            int tongVe = Integer.parseInt(nhap.readLine());
            System.out.print("Nhap so ve nguoi lon: ");
            int nguoiLon = Integer.parseInt(nhap.readLine());
            System.out.print("Nhap so ve tre em: ");
            int treEm = Integer.parseInt(nhap.readLine());
            int nguoiGia = tongVe - (nguoiLon + treEm);
            double[] tongTien = new double[3];
            tongTien = tinhTien(loaiGhe, nguoiLon, treEm, nguoiGia);
            double tongSoTien = 0;
            for (double value : tongTien) {
                tongSoTien += value;
            }
            System.out.println("------------------------------");
            System.out.println("Tong so ve: " + tongVe);
            System.out.println("Ve nguoi lon: " + nguoiLon + " ve. Thanh tien: " + tongTien[0] + " vnd");
            System.out.println("Ve tre em: " + treEm + " ve. Thanh tien: " + tongTien[1] + " vnd");
            System.out.println("Ve nguoi gia: " + nguoiGia + " ve. Thanh tien: " + tongTien[2] + " vnd");
            System.out.println("Tong so tien: " + tongSoTien + " vnd");
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
