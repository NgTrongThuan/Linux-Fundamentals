/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import com.sun.xml.internal.ws.wsdl.parser.InaccessibleWSDLException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1TinhCuoc {

    enum GoiCuoc {
        M0(1, 0, 0, 1.5),
        M10(2, 10000, 51200, 0.5),
        M25(3, 25000, 153600, 0.5),
        M50(4, 50000, 512000, 0.5),
        M120(5, 120000, 1572864, 0.5),
        MAX(6, 70000, 614400, 0),
        MAX100(7, 100000, 1258291.2, 0),
        MAX200(8, 200000, 3145728, 0),
        MAXS(9, 50000, 2097152, 0);
        private double stt;
        private double cuocTB;
        private double dungLuongMienPhi;
        private double cuocDLVuotGoi;

        private GoiCuoc(double stt, double cuocTB, double dungLuongMienPhi, double cuocDLVuotGoi) {
            this.stt = stt;
            this.cuocTB = cuocTB;
            this.dungLuongMienPhi = dungLuongMienPhi;
            this.cuocDLVuotGoi = cuocDLVuotGoi;
        }

        public double getSTT() {
            return stt;
        }

        public double getCuocTB() {
            return cuocTB;
        }

        public double getDungLuongMP() {
            return dungLuongMienPhi;
        }

        public double getCuocDLVuotGoi() {
            return cuocDLVuotGoi;
        }

        public double tinhTien(double dungLuong) {
            double kq = 0;
            if (dungLuong >= this.dungLuongMienPhi) {
                kq = this.getCuocTB() + (dungLuong - this.getDungLuongMP()) * this.getCuocDLVuotGoi();
            } else {
                kq = this.getCuocTB();
            }
            return kq;
        }

    }

    public static double tinhTien(int stt, double dungLuong) {
        if (stt <= 0 || stt > 9) {
            throw new ArithmeticException("Nhap khong dung goi cuoc");
        }
        if (dungLuong <= 0) {
            throw new ArithmeticException("Dung luong khong hop le");
        }
        GoiCuoc goiCuoc = null;
        double tongTien = 0;
        switch (stt) {
            case 1:
                tongTien = goiCuoc.M0.tinhTien(dungLuong);
                break;
            case 2:
                tongTien = goiCuoc.M10.tinhTien(dungLuong);
                break;
            case 3:
                tongTien = goiCuoc.M25.tinhTien(dungLuong);
                break;
            case 4:
                tongTien = goiCuoc.M50.tinhTien(dungLuong);
                break;
            case 5:
                tongTien = goiCuoc.M120.tinhTien(dungLuong);
                break;
            case 6:
                tongTien = goiCuoc.MAX.tinhTien(dungLuong);
                break;
            case 7:
                tongTien = goiCuoc.MAX100.tinhTien(dungLuong);
                break;
            case 8:
                tongTien = goiCuoc.MAX200.tinhTien(dungLuong);
                break;
            default:
                tongTien = goiCuoc.MAXS.tinhTien(dungLuong);
                break;
        }
        return tongTien;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhap goi cuoc: \n1.M0\n2.M10\n3.M25\n4.M50\n5.M120\n6.MAX\n7.MAX100\n8.MAX200\n9.MAXS\n");
            int stt = Integer.parseInt(nhap.readLine());
            System.out.print("Nhap dung luong (kb): ");
            double dungLuong = Double.parseDouble(nhap.readLine());
            System.out.println("Tong tien thanh toan: " + tinhTien(stt, dungLuong));
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
