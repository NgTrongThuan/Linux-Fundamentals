/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai8DiemSinhVien {

    public static int[] mangDiemSV(int n) {
        int[] diem = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            diem[i] = random.nextInt(101);
        }
        return diem;
    }

    public static void xuatMang(int[] a) {
        for (int value : a) {
            System.out.print(value + " ");
        }
    }

    public static String demSinhVien(int[] a, int soDau, int soCuoi) {
        String dem = "";
        for (int i = 0; i < a.length; i++) {
            if (a[i] >= soDau && a[i] <= soCuoi) {
                dem += "*";
            }
        }
        return dem;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so sinh vien: ");
            int n = Integer.parseInt(nhap.readLine());
            int[] diem = mangDiemSV(n);
            System.out.println("Diem cua Sinh vien:");
            xuatMang(diem);
            System.out.println("\n-----------------------------");
            System.out.println("Thong ke diem:");
            System.out.println("0  - 9 : " + demSinhVien(diem, 0, 9));
            System.out.println("10 - 19: " + demSinhVien(diem, 10, 19));
            System.out.println("20 - 29: " + demSinhVien(diem, 20, 29));
            System.out.println("30 - 39: " + demSinhVien(diem, 30, 39));
            System.out.println("40 - 49: " + demSinhVien(diem, 40, 49));
            System.out.println("50 - 59: " + demSinhVien(diem, 50, 59));
            System.out.println("60 - 69: " + demSinhVien(diem, 60, 69));
            System.out.println("70 - 79: " + demSinhVien(diem, 70, 79));
            System.out.println("80 - 89: " + demSinhVien(diem, 80, 89));
            System.out.println("90 - 100: " + demSinhVien(diem, 90, 100));

        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
