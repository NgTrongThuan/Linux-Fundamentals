/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2MaTranVuong {

    final static int CUC_AM = -999999;
    final static int CUC_DUONG = 9999999;

    public static int timSoLonNhat(int[] a) {
        int kq = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] > kq) {
                kq = a[i];
            }
        }
        return kq;
    }

    public static int timSoNhoNhat(int[] a) {
        int kq = a[0];
        for (int i = 1; i < a.length; i++) {
            if (a[i] < kq) {
                kq = a[i];
            }
        }
        return kq;
    }

    public static void thayX(int[][] a, int x) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if ((i == j) || (i + j == a.length - 1)) {
                    a[i][j] = x;
                }
            }
        }
    }

    public static int timSoDuongNhoNhat(int[][] a) {
        int kq = CUC_DUONG;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] > 0 && a[i][j] < kq) {
                    kq = a[i][j];
                }
            }
        }
        return kq;
    }

    public static int timSoAmLonNhat(int[][] a) {
        int kq = CUC_AM;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] < 0 && a[i][j] > kq) {
                    kq = a[i][j];
                }
            }
        }
        return kq;
    }

    public static void xuatMang(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println("\n");
        }
    }

    public static int demSoDuong(int[][] a) {
        int kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i <= j && a[i][j] >= 0) {
                    kq++;
                }
            }
        }
        return kq;
    }

    public static int demSoChiaHet(int[][] a) {
        int kq = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] < 0 && a[i][j] % 2 == 0 && a[i][j] % 3 == 0) {
                    kq++;
                }
            }
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap kich thuoc ma tran: ");
            int n = Integer.parseInt(nhap.readLine());
            if (n <= 0) {
                throw new ArithmeticException("Nhap kich thuoc ma tran khong dung!");
            }
            int[][] a = new int[n][n];
            System.out.println("Nhap gia tri cho ma tran: ");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    a[i][j] = Integer.parseInt(nhap.readLine());
                }
            }

            System.out.println("-------------------------------------------");
            System.out.println("Ma tran vua nhap la: ");
            xuatMang(a);

            for (int i = 0; i < a.length; i++) {
                System.out.println("Gia tri lon nhat tai dong " + i + " la: " + timSoLonNhat(a[i]));
                System.out.println("Gia tri nho nhat tai dong " + i + " la: " + timSoNhoNhat(a[i]));
                System.out.println("------------------------------------------");
            }

            System.out.print("Nhap so nguyen x:");
            int x = Integer.parseInt(nhap.readLine());

            thayX(a, x);
            xuatMang(a);

            System.out.println("Phan tu duong nho nhat la: " + timSoDuongNhoNhat(a));
            System.out.println("Phan tu am lon nhat la: " + timSoAmLonNhat(a));
            System.out.println("So phan tu duong tam giac phia tren duong cheo chinh la: " + demSoDuong(a));
            System.out.println("So phan tu am % 2 va % 3 la: " + demSoChiaHet(a));

        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
