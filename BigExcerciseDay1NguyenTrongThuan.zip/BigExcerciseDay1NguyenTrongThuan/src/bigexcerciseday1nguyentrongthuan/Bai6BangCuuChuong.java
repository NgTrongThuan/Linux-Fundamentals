/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai6BangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static String[][] taoBangCuuChuong(int tuSo, int denSo) {
        if (tuSo <= 0 || denSo <= 0 || tuSo >= denSo) {
            throw new ArithmeticException("Nhap du lieu khong hop le");
        }
        int doDai = denSo - tuSo;
        String[][] kq = new String[doDai+1][11];
        for (int i = 0; i < doDai + 1; i++) {
            kq[i][0] = "" + (i + 1);
            kq[i][1] = "" + "|";
            for (int j = 2; j < 11; j++) {
                kq[i][j] = "" + (i + 1) * (j - 1);
            }
        }
        return kq;
    }

    public static void xuatBangCuuChuong(String[][] a) {
        System.out.println("Cot| 1 2 3 4 5 6 7 8 9\nCuu chuong");
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println("\n");
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so bat dau: ");
            int tuSo = Integer.parseInt(nhap.readLine());
            System.out.print("Nhap so ket thuc: ");
            int denSo = Integer.parseInt(nhap.readLine());
            String[][] bangCuuChuong = taoBangCuuChuong(tuSo, denSo);
            xuatBangCuuChuong(bangCuuChuong);
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }

    }

}
