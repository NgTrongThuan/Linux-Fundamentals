/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai4MangChuoi {

    public static void xuatMang(String[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println("Phan tu thu " + i);
            System.out.println("\tNoi dung: " + a[i]);
            System.out.println("\tChieu dai: " + a[i].length());
        }
    }

    public static String timPhanTuDaiNhat(String[] a) {
        String kq = "";
        String daiNhat = a[0];
        for (int i = 1; i < a.length; i++) {
            if (a[i].length() >= daiNhat.length()) {
                kq += a[i] + " ";
            }
        }
        return kq;
    }

    public static void sapXep(String[] a){
        Arrays.sort(a);
    }
    public static String timViTri(String[] a, String x) {
        String kq = "";
        int tam = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i].equals(x)) {
                kq += i + " ";
            }
        }
        return kq;
    }
    
    public static boolean ktraChuoi(String[] a, String x){
        for(String value: a){
            if(x.equals(value)){
                return true;
            }
        }
        return false;
    }
    
    public static String[] taoMangMoi(String[] a){
        int length = a.length;
        String[] kq = new String[length];
        for(int i = 0; i < length; i++){
            kq[i] = a[i];
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhap so phan tu n: ");
            int n = Integer.parseInt(nhap.readLine());
            String[] a = new String[n];
            for (int i = 0; i < n; i++) {
                System.out.print("Nhap noi dung phan tu thu " + i + " : ");
                a[i] = nhap.readLine();
            }
            xuatMang(a);

            String tam = timPhanTuDaiNhat(a);
            String[] kq = tam.split(" ");
            System.out.println("Phan tu co chuoi dai nhat: ");
            for (int i = 0; i < kq.length; i++) {
                    System.out.println(kq[i] + " o vi tri: " + timViTri(a, kq[i]));
            }
            System.out.println("------------------------------------------");
            
            System.out.print("Nhap vao 1 chuoi:" );
            String chuoi = nhap.readLine();
            if(ktraChuoi(a, chuoi)){
                System.out.println("Chuoi vua nhap giong phan tu thu " + timViTri(a, chuoi));
            }else{
                System.out.println("Chuoi vua nhap khong trung voi phan tu trong mang");
            }
            System.out.println("------------------------------------------");
            String[] mang = taoMangMoi(a);
            System.out.println("Mang moi co gia tri la: ");
            for(String value: mang){
                System.out.print(value + " ");
            }
            System.out.println("\n------------------------------------------");
            sapXep(a);
            System.out.println("Mang sau khi sap xep la: ");
            for(String value: a){
                System.out.print(value + " ");
            }
            
        } catch (NumberFormatException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
