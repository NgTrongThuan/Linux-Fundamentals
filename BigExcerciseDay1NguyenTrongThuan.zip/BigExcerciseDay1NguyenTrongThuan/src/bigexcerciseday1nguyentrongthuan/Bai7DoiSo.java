/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexcerciseday1nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai7DoiSo {

    public static StringBuffer doiHe10Sang16(int n) {
        String so = "";
        int tam = 0;
        while (n > 0) {
            tam = n % 16;
            switch (tam) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                    so += tam;
                    break;
                case 10:
                    so += "A";
                    break;
                case 11:
                    so += "B";
                    break;
                case 12:
                    so += "C";
                    break;
                case 13:
                    so += "D";
                    break;
                case 14:
                    so += "E";
                    break;
                case 15:
                    so += "F";
                    break;
            }
            n /= 16;
        }
        StringBuffer kq = new StringBuffer(so);
        kq.reverse();
        return kq;
    }

    public static int doiHe16Sang10(String n) {
        int kq = 0;
        int soMu = n.length();
        int tam = 0;
        for (int i = 0; i < n.length(); i++) {
            switch (n.charAt(i)) {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    tam = Integer.parseInt(n.charAt(i) + "");
                    break;
                case 'A':
                    tam = 10;
                    break;
                case 'B':
                    tam = 11;
                    break;
                case 'C':
                    tam = 12;
                    break;
                case 'D':
                    tam = 13;
                    break;
                case 'E':
                    tam = 14;
                    break;
                case 'F':
                    tam = 15;
                    break;
            }
            kq += tam * Math.pow(16, soMu - 1);
            soMu--;
        }
        return kq;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Chon:\n(1)Chuyen so thap phan sang thap luc phan.\n(2)Chuyen so thap luc phan sang thap phan.");
            int chon = Integer.parseInt(nhap.readLine());
            switch (chon) {
                case 1: {
                    System.out.println("Chuyen so thap phan sang thap luc phan");
                    System.out.print("Nhap so he thap phan: ");
                    int so = Integer.parseInt(nhap.readLine());
                    System.out.println("Ket qua: " + doiHe10Sang16(so));
                }
                break;
                case 2: {
                    System.out.println("Chuyen so thap luc phan sang thap phan");
                    System.out.print("Nhap so he thap luc phan: ");
                    String so = nhap.readLine().toUpperCase();
                    String regexp = "^([a-fA-F0-9]+)$";
                    Pattern pattern = Pattern.compile(regexp);
                    Matcher matcher = pattern.matcher(so);
                    if (matcher.find()) {
                        System.out.println("Ket qua: " + doiHe16Sang10(so));
                    }else{
                        System.out.println("Khong dung dinh dang so phap luc phan");
                    }
                }

            }
        } catch (NumberFormatException | ArithmeticException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

}
