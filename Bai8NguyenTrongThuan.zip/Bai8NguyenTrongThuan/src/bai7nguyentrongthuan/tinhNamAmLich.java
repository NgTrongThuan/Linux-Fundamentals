/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhNamAmLich {

    /**
     * @param args the command line arguments
     */
    public static String tinhCan(int year) {
        String ketQua = "";
        int tam = year % 10;
        switch (tam) {
            case 0:
                ketQua = "Canh";
                break;
            case 1:
                ketQua = "Tân";
                break;
            case 2:
                ketQua = "Nhâm";
                break;
            case 3:
                ketQua = "Quý";
                break;
            case 4:
                ketQua = "Giáp";
                break;
            case 5:
                ketQua = "Ất";
                break;
            case 6:
                ketQua = "Bính";
                break;
            case 7:
                ketQua = "Đinh";
                break;
            case 8:
                ketQua = "Mậu";
                break;
            default:
                ketQua = "Kỷ";
                break;
        }
        return ketQua;
    }

    public static String tinhChi(int year) {
        String ketQua = "";
        int tam = year % 12;
        switch (tam) {
            case 0:
                ketQua = "Thân";
                break;
            case 1:
                ketQua = "Dậu";
                break;
            case 2:
                ketQua = "Tuất";
                break;
            case 3:
                ketQua = "Hợi";
                break;
            case 4:
                ketQua = "Tý";
                break;
            case 5:
                ketQua = "Sửu";
                break;
            case 6:
                ketQua = "Dần";
                break;
            case 7:
                ketQua = "Mão";
                break;
            case 8:
                ketQua = "Thìn";
                break;
            case 9:
                ketQua = "Tỵ";
                break;
            case 10:
                ketQua = "Ngọ";
                break;
            default:
                ketQua = "Mùi";
                break;
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Nhập năm sinh : ");
        int nam = Integer.parseInt(nhap.readLine());
        
        System.out.println(tinhCan(nam) + " " + tinhChi(nam));
    }

}
