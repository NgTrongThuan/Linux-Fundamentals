/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author Win7-64 SP1
 */
public class xulyMaTranVuong {

    /**
     * @param args the command line arguments
     */
    public static double tinhTongDuongCheoChinh(int[][] a) {
        double ketQua = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == j) {
                    ketQua += a[i][j];
                }
            }
        }
        return ketQua;
    }

    // Tìm giá trị nhỏ nhất trên đường chéo chính
    public static int timGiaTriNhoNhat(int[][] a) {
        int ketQua = a[0][0];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == j) {
                    if (a[i][j] <= ketQua) {
                        ketQua = a[i][j];
                    }
                }
            }
        }
        return ketQua;
    }

    public static int timGiaTriLonNhat(int[][] a) {
        int ketQua = a[0][0];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == j) {
                    if (a[i][j] >= ketQua) {
                        ketQua = a[i][j];
                    }
                }
            }
        }
        return ketQua;
    }

    public static boolean kiemTraSoNT(int n) {
        if (n < 2) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 2; i < Math.sqrt(n) + 1; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static String timSoNT(int[][] a) {
        String ketQua = "";
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (kiemTraSoNT(a[i][j])) {
                    ketQua += a[i][j] + " nằm ở dòng " + i + " và cột " + j + "\n";
                }
            }
        }
        return ketQua;
    }

    public static boolean kiemTraMaTranDoiXung(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] != a[j][i]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static int[][] tinhTongHaiMaTran(int[][] a, int[][] b) {
        int m = a.length;
        int[][] ketQua = new int[m][m];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                ketQua[i][j] = a[i][j] + b[i][j];
            }
        }
        return ketQua;
    }

    public static boolean kiemTraTangDan(int[][] a, int k) {
        for (int i = 0; i < a.length - 1; i++) {
            if ((a[i][k] > a[i + 1][k])) {
                return false;
            }
        }
        return true;
    }

    public static boolean kiemTraGiamDan(int[][] a, int k) {
        for (int i = 0; i < a.length - 1; i++) {
            if ((a[i][k] < a[i + 1][k])) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập m:");
        int m = Integer.parseInt(nhap.readLine());

        int[][] a = new int[m][m];
        Random random = new Random();
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = random.nextInt(20);
            }
        }

        System.out.println("Ma trận vuông a: ");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println("\n");
        }

        System.out.println("Tổng các giá trị trên đường chéo chính là: " + tinhTongDuongCheoChinh(a));
        System.out.println("Giá trị nhỏ nhất trên đường chéo chính là: " + timGiaTriNhoNhat(a));
        System.out.println("Giá trị lớn nhất trên đường chéo chính là: " + timGiaTriLonNhat(a));
        System.out.println("Các số nguyên tố trong mảng và vị trí:");
        String ketQua = timSoNT(a);
        System.out.println(timSoNT(a));
        System.out.println("*************************************************");
        int[][] b = new int[m][m];
        System.out.println("Nhập giá trị cho ma trận vuông b:");
        for (int i = 0; i < m; i++) {
            System.out.println("Nhập dòng thứ " + i + ":");
            for (int j = 0; j < m; j++) {
                System.out.print("   Nhập cột thứ " + j + ": ");
                b[i][j] = Integer.parseInt(nhap.readLine());
            }
        }
        System.out.println("\nMa trận b vừa nhập:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(b[i][j] + "\t");
            }
            System.out.println("\n");
        }

        if (kiemTraMaTranDoiXung(b)) {
            System.out.println("Ma trận b đối xứng qua đường chéo chính !");
        } else {
            System.out.println("Ma trận b KHÔNG đối xứng qua đường chéo chính !");
        }
        System.out.println("*************************************************");

        int[][] c = new int[m][m];
        c = tinhTongHaiMaTran(a, b);
        System.out.println("Kết quả ma trận c = a + b là :");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(c[i][j] + "\t");
            }
            System.out.println("\n");
        }
        System.out.println("*************************************************");

        System.out.print("Nhập giá trị k: ");
        int k = Integer.parseInt(nhap.readLine());
        if (kiemTraTangDan(a, k)) {
            System.out.println("Các giá trị trong ma trận tại cột " + k + " tăng dần");
        } else {
            System.out.println("Các giá trị trong ma trận tại cột " + k + " KHÔNG tăng dần");
        }
        if (kiemTraGiamDan(a, k)) {
            System.out.println("Các giá trị trong ma trận tại cột " + k + " giảm dần");
        } else {
            System.out.println("Các giá trị trong ma trận tại cột " + k + " KHÔNG giảm dần");
        }
    }

}
