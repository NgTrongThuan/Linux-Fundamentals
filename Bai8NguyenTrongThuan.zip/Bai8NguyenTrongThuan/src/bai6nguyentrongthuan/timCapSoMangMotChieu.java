/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timCapSoMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static String timCapSoChiaHet(int[] arr) {
        if (arr == null) {
            throw new NegativeArraySizeException("a");
        }
        String ketQua = "";
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] % arr[j] == 0) || (arr[j] % arr[i] == 0)) {
                    ketQua += arr[i] + " & " + arr[j] + ", ";
                }
            }
        }
        return ketQua;
    }

    public static String timCapSoGapDoi(int[] arr) {
        if (arr == null) {
            throw new NegativeArraySizeException("a");
        }
        String ketQua = "";
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] * 2 == arr[j]) || (arr[j] * 2 == arr[i])) {
                    ketQua += arr[i] + " & " + arr[j] + ", ";
                }
            }
        }
        return ketQua;
    }

    public static String timCapSoTongBang8(int[] arr) {
        if (arr == null) {
            throw new NegativeArraySizeException("a");
        }
        String ketQua = "";
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] + arr[j] == 8) || (arr[j] + arr[i] == 8)) {
                    ketQua += arr[i] + " & " + arr[j] + ", ";
                }
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        
        int[] a = new int[0];

        try {
            System.out.println("Nhập n: ");
            int n = Integer.parseInt(nhap.readLine());
            if (n <= 0) {
                throw new ArithmeticException("Kích thước mảng phải lớn hơn 0");
            }
            int[] arr = new int[n];
            System.out.println("Nhập vào giá trị phần tử của mảng: ");
            for (int i = 0; i < n; i++) {
                arr[i] = Integer.parseInt(nhap.readLine());
            }

            System.out.print("Cặp số có quan hệ chia hết: ");
            System.out.println(timCapSoChiaHet(arr));
            System.out.print("Cặp số có quan hệ gấp đôi: ");
            System.out.println(timCapSoGapDoi(arr));
            System.out.print("Cặp số có tổng bằng 8: ");
            System.out.println(timCapSoTongBang8(arr));
        } catch (NumberFormatException | ArithmeticException | NegativeArraySizeException ex) {
            System.err.println("Error: " + ex.getMessage());
        }

    }

}
