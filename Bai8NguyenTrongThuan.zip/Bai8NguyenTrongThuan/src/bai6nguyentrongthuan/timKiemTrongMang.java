/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timKiemTrongMang {

    /**
     * @param args the command line arguments
     */
    public static String timKiem(int[] a, int x) {
        String ketQua = "";
        for (int i = 0; i < a.length; i++) {
            if (a[i] == x) {
                ketQua += i + ", ";
            }
        }
        return ketQua;
    }

    public static boolean kiemTraLonHon(int[] a, int x) {
        for (int value : a) {
            if (x < value) {
                return false;
            }
        }
        return true;
    }
    
    //Hàm tìm số nhỏ hơn x
    public static String timSoLonHon(int[] a, int x){
        String ketQua = "";
        for(int value: a){
            if(value > x){
                ketQua += value + ", ";
            }
        }
        return ketQua;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhập n:");
        int n = Integer.parseInt(nhap.readLine());
        int[] arr = new int[n];

        System.out.println("Nhập giá trị cho các phần tử trong mảng:");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(nhap.readLine());
        }

        System.out.println("Nhập x:");
        int x = Integer.parseInt(nhap.readLine());

        String rs = " ";
        for (int value : arr) {
            rs += value + " ";
        }
        System.out.println("Mảng đã nhập:" + rs);

        String ketQua = timKiem(arr, x);
        if (ketQua.equals("")) {
            System.out.println("Số " + x + " không xuất hiện trong mảng !");
        } else {
            System.out.println("Số " + x + " xuất hiện tại vị trí: " + ketQua);
        }

        String soLonHon = timSoLonHon(arr, x);
        
        if(kiemTraLonHon(arr, x)){
            System.out.println(x + " lớn hơn các số khác trong mảng a.");
        }
        else{
            System.out.println(x + " không lớn hơn các số khác trong mảng.");
            System.out.println(x + " nhỏ hơn các số: " + soLonHon);
        }
        

    }
}
