/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static double tinhToanBT(int x, int y) {
        double tam = 0;
        double tuSo = 5 * x - y;
        double mauSo = 2 * x + 7 * y;
        if (mauSo == 0) {
            throw new ArithmeticException("Biểu thức không xác định do có mẫu bằng 0 !");
        }
        tam = tuSo / mauSo;
        if (tam < 0) {
            throw new ArithmeticException("Biểu thức trong căn mang giá trị âm nên không tính được căn bậc hai");

        }
        return Math.sqrt(tam);

    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Nhập x: ");
            int x = Integer.parseInt(nhap.readLine());

            System.out.print("Nhập y: ");
            int y = Integer.parseInt(nhap.readLine());

            System.out.println("Kết quả A = " + tinhToanBT(x, y));
        } catch (IOException | NumberFormatException | ArithmeticException ex) {
            System.err.println("Error: " + ex.getMessage());
        }

    }

}
