/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timKiemTrongMang {

    /**
     * @param args the command line arguments
     */
    public static int timX(int x, int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] == x) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try{
        System.out.println("Nhập n:");
        int n = Integer.parseInt(nhap.readLine());
        if(n <= 0)throw new ArithmeticException("Kích thước mảng là phải là số dương");
        int[] arr = new int[n];

        System.out.println("Nhập giá trị cho các phần tử trong mảng:");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(nhap.readLine());
        }

        System.out.println("Nhập x:");
        int x = Integer.parseInt(nhap.readLine());

        String rs = " ";
        for (int value : arr) {
            rs += value + " ";
        }
        System.out.println("Mảng đã nhập:" + rs);

        System.out.println("Kết quả tìm " + x + " là: " +timX(x, arr));
        }catch(NumberFormatException | ArithmeticException ex){
            System.err.println("Error: " + ex.getMessage());
        }
    }
}
