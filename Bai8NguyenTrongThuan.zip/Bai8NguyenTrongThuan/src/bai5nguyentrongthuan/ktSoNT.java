/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class ktSoNT {

    /**
     * @param args the command line arguments
     */
    public static boolean kiemTraSoNTFor(int n) {
        if (n < 0) {
            throw new ArithmeticException("Số nhập vào phải là số dương");
        }
        if (n <= 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean kiemTraSoNTWhile(int n) {
        if (n < 0) {
            throw new ArithmeticException("số nhập vào phải là số dương");
        }
        int i = 2;

        if (n <= 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        while (i <= Math.sqrt(n)) {
            if (n % i == 0) {
                return false;
            }
            i++;
        }
        return true;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập n: ");
            int n = Integer.parseInt(nhap.readLine());

            System.out.println("Sử dụng for: ");
            if (kiemTraSoNTFor(n)) {
                System.out.println(n + " là số nguyên tố !");
            } else {
                System.out.println(n + " không phải là số nguyên tố !");
            }
            System.out.println("Sử dụng while: ");
            if (kiemTraSoNTWhile(n)) {
                System.out.println(n + " là số nguyên tố !");
            } else {
                System.out.println(n + " không phải là số nguyên tố !");
            }
        } catch (NumberFormatException | ArithmeticException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
    }

}
