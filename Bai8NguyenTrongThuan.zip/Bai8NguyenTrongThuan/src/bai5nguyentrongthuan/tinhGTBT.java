/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static boolean kiemTraSoLe(int n) {
        return n % 2 != 0;
    }

    public static boolean kiemTraSoChan(int n) {
        return n % 2 == 0;
    }

    public static int tinhTongSoLeFor(int n) {
        int tong = 0; //n = 0
        for (int i = 1; i <= n; i += 2) {
            tong += i;
        }
        return tong;
    }

    public static int tinhTongSoLeWhile(int n) {
        int tong = 0; //n = 0
        int i = 1;
        while (i <= n) {
            tong += i;
            i += 2;
        }
        return tong;
    }

    public static int tinhTongSoChanFor(int n) {
        int tong = 0;
        for (int i = 0; i <= n; i += 2) {
            tong += i;
        }
        return tong;
    }

    public static int tinhTongSoChanWhile(int n) {
        int tong = 0;
        int i = 0;
        while (i <= n) {
            tong += i;
            i += 2;
        }
        return tong;
    }

    public static int tinhTichFor(int n) {
        int tich = 1;
        if (n == 0) {
            tich = 0;
        }
        for (int i = 1; i <= n; i++) {
            tich *= i;
        }
        return tich;
    }

    public static int tinhTichWhile(int n) {
        int tich = 1;
        int i = 1;

        if (n == 0) {
            tich = 0;
        }

        while (i <= n) {
            tich *= i;
            i++;
        }
        return tich;
    }

    public static int tinhTichChiaHetCho3For(int n) {
        int tich = 1;
        if (n < 3) {
            tich = 0;
        }
        for (int i = 3; i <= n; i += 3) {
            tich *= i;
        }
        return tich;
    }

    public static int tinhTichChiaHetCho3While(int n) {
        int tich = 1;
        int i = 3;
        if (n < 3) {
            tich = 0;
        }
        while (i <= n) {
            tich *= i;
            i += 3;
        }
        return tich;
    }

    public static boolean kiemTraSNT(int n) {
        if (n <= 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static int tongSoNTFor(int n) {
        int tong = 0;
        for (int i = 0; i <= n; i++) {
            if (kiemTraSNT(i)) {
                tong += i;
            }
        }
        return tong;
    }

    public static int tongSoNTWhile(int n) {
        if (n < 0) {
            throw new ArithmeticException("Số nhập vào phải là số dương");
        }
        int tong = 0;
        int i = 0;
        while (i <= n) {
            if (kiemTraSNT(i)) {
                tong += i;
            }
            i++;
        }
        return tong;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập n: ");
            int n = Integer.parseInt(nhap.readLine());

            System.out.println("Sử dụng for:");
            System.out.println("Kết quả A = " + tinhTongSoLeFor(n));
            System.out.println("Kết quả B = " + tinhTongSoChanFor(n));
            System.out.println("Kết quả C = " + tinhTichFor(n));
            System.out.println("Kết quả D = " + tinhTichChiaHetCho3For(n));
            System.out.println("Kết quả E = " + tongSoNTFor(n));
            System.out.print("\n");
            System.out.println("Sử dụng while:");
            System.out.println("Kết quả A = " + tinhTongSoLeWhile(n));
            System.out.println("Kết quả B = " + tinhTongSoChanWhile(n));
            System.out.println("Kết quả C = " + tinhTichWhile(n));
            System.out.println("Kết quả D = " + tinhTichChiaHetCho3While(n));
            System.out.println("Kết quả E = " + tongSoNTWhile(n));
        } catch (NumberFormatException | ArithmeticException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
    }

}
