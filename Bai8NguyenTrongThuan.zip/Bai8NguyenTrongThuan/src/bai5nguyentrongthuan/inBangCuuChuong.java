/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5nguyentrongthuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Win7-64 SP1
 */
public class inBangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static void inBangCuuChuongWhile(int tuSo, int denSo) {
        if (tuSo < 0) {
            throw new ArithmeticException("Số nhập vào là số âm");
        }
        if (denSo < 0) {
            throw new ArithmeticException("Số nhập vào là số âm");
        }
        int i = 1;
        int j = tuSo;
        while (i <= 9) {
            j = tuSo;
            while (j <= denSo) {
                System.out.print(i + " x " + j + " = " + i * j + "\t");
                j++;
            }
            System.out.println("");
            i++;
        }
    }

    public static void inBangCuuChuongFor(int tuSo, int denSo) {
        if (tuSo < 0) {
            throw new ArithmeticException("Số nhập vào là số âm");
        }
        if (denSo < 0) {
            throw new ArithmeticException("Số nhập vào là số âm");
        }
        for (int i = 1; i <= 9; i++) {
            for (int j = tuSo; j <= denSo; j++) {
                System.out.print(j + " x " + i + " = " + j * i + "\t");
            }
            System.out.println("");
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Từ số: ");
        int tuSo = Integer.parseInt(nhap.readLine());
        System.out.println("Đến số: ");
        int denSo = Integer.parseInt(nhap.readLine());

        System.out.println("****************************************************"
                + "****************************************");
        System.out.println("    In bản cửu chương For");
        System.out.println("****************************************************"
                + "****************************************");
        System.out.println("Từ số: " + tuSo);
        System.out.println("Đến số: " + denSo);
        System.out.println("----------------------------------------------------"
                + "----------------------------------------");
        try {
            inBangCuuChuongFor(tuSo, denSo);
        } catch (NumberFormatException | ArithmeticException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
        System.out.println("----------------------------------------------------"
                + "----------------------------------------");
        System.out.println("****************************************************"
                + "****************************************");
        System.out.println("    In bản cửu chương While");
        System.out.println("****************************************************"
                + "****************************************");
        System.out.println("Từ số: " + tuSo);
        System.out.println("Đến số: " + denSo);
        System.out.println("----------------------------------------------------"
                + "----------------------------------------");
        try{
            inBangCuuChuongWhile(tuSo, denSo);
        } catch (NumberFormatException | ArithmeticException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
        

    }

}
